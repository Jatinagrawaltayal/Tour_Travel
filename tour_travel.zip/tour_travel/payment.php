<?php
include "includes/user_header.php";

// Get data
$total_amount = $_POST['total_amount'];
$name = $_POST['name'];
$email = $_POST['email'];
$package_name = $_POST['package_name'];
?>

<!DOCTYPE html>
<html>
<head>
<title>Secure Payment</title>

<style>
body{
margin:0;
font-family:'Segoe UI', sans-serif;
background:linear-gradient(135deg,#74ebd5,#ACB6E5);
}

/* Main Card */
.container{
max-width:500px;
margin:50px auto;
background:white;
border-radius:15px;
box-shadow:0 10px 25px rgba(0,0,0,0.2);
overflow:hidden;
}

/* Header */
.header{
background:#2c3e50;
color:white;
padding:20px;
text-align:center;
font-size:22px;
letter-spacing:1px;
}

/* Content */
.content{
padding:25px;
}

/* Info */
.info p{
margin:10px 0;
font-size:16px;
}

/* Amount Highlight */
.amount{
background:#ecf0f1;
padding:15px;
border-radius:10px;
text-align:center;
font-size:22px;
font-weight:bold;
margin:15px 0;
}

/* Fake Processing Animation */
.processing{
text-align:center;
margin:20px 0;
color:#888;
font-size:14px;
}

/* Button */
.btn{
width:100%;
padding:14px;
background:linear-gradient(45deg,#27ae60,#2ecc71);
border:none;
border-radius:8px;
color:white;
font-size:18px;
cursor:pointer;
transition:0.3s;
}
.btn:hover{
transform:scale(1.03);
}

/* Secure Badge */
.secure{
text-align:center;
margin-top:15px;
font-size:13px;
color:#777;
}
</style>

</head>

<body>

<div class="container">

<div class="header">
🔒 Secure Payment Gateway
</div>

<div class="content">

<div class="info">
<p><strong>Name:</strong> <?php echo $name; ?></p>
<p><strong>Email:</strong> <?php echo $email; ?></p>
<p><strong>Package:</strong> <?php echo $package_name; ?></p>
</div>

<div class="amount">
₹<?php echo $total_amount; ?>
</div>

<!-- Fake Processing -->
<div class="processing" id="processingText">
Connecting to secure payment server...
</div>

<!-- FORM -->
<form id="paymentForm" action="payment_success.php" method="POST" onsubmit="return fakeProcess()">

<input type="hidden" name="name" value="<?php echo $name; ?>">
<input type="hidden" name="email" value="<?php echo $email; ?>">
<input type="hidden" name="package_name" value="<?php echo $package_name; ?>">
<input type="hidden" name="amount" value="<?php echo $total_amount; ?>">
<input type="hidden" name="payment_method" value="Cash">

<button class="btn" id="payBtn">
Proceed to Pay
</button>

</form>

<div class="secure">
🔐 100% Secure | Cash on Arrival Available
</div>

</div>

</div>

<script>
function fakeProcess(){

let text = document.getElementById("processingText");
let btn = document.getElementById("payBtn");

btn.innerHTML = "Processing...";
btn.disabled = true;

let steps = [
"Connecting to bank...",
"Verifying details...",
"Securing transaction...",
"Payment Authorized..."
];

let i = 0;

let interval = setInterval(()=>{
if(i < steps.length){
text.innerHTML = steps[i];
i++;
}else{
clearInterval(interval);
document.getElementById("paymentForm").submit();
}
},800);

return false;
}
</script>

</body>
</html>