<?php
  include 'includes/user_header.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <title>Go Trip</title>
    <style>
        /* About Section */
        .about {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 50px 20px;
            max-width: 1200px;
            margin: 0 auto;
            background-color: #fff; /* White background for the about section */
            border-radius: 10px; /* Rounded corners */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* Subtle shadow */
        }

        .about .image {
            flex: 1; /* Take up 50% of the space */
            margin-right: 20px; /* Space between image and content */
        }

        .about .image img {
            width: 100%; /* Full width */
            border-radius: 10px; /* Rounded corners */
            height: auto; /* Maintain aspect ratio */
        }

        .about .content {
            flex: 1; /* Take up 50% of the space */
            text-align: left; /* Align text to the left */
        }

        .about .content h3 {
            font-size: 2rem; /* Title size */
            margin-bottom: 20px; /* Space below title */
            color: #333; /* Dark text */
        }

        .about .content p {
            font-size: 1rem; /* Description size */
            color: #666; /* Lighter text */
            margin-bottom: 20px; /* Space below description */
            line-height: 1.6; /* Line height for readability */
        }

        .icons-container {
            display: flex;
            justify-content: space-between; /* Space between icons */
            margin-top: 20px; /* Space above icons */
        }

        .icons {
            display: flex;
            align-items: center; /* Center icons vertically */
            color: #333; /* Dark text */
        }

        .icons i {
            font-size: 2rem; /* Icon size */
            margin-right: 10px; /* Space between icon and text */
            color: #3498db; /* Main color for icons */
        }

        /* Customer Testimonials Section */
        .customer-testimonials {
            padding: 50px 20px;
            background-color: #fff; /* White background for testimonials */
            margin-top: 40px; /* Space above testimonials */
            border-radius: 10px; /* Rounded corners */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* Subtle shadow */
        }

        .testimonials-header {
            text-align: center; /* Center the header */
            margin-bottom: 30px; /* Space below header */
        }

        .testimonials-header h2 {
            font-size: 2.5rem; /* Header size */
            color: #333; /* Dark text */
        }

        .testimonials-header p {
            font-size: 1.2rem; /* Subheader size */
            color: #666; /* Lighter text */
        }

        .reviews-slider {
            display: flex;
            overflow-x: auto; /* Horizontal scrolling */
            gap: 20px; /* Space between reviews */
        }

        .review-container {
            background-color: #f9f9f9; /* Light background for reviews */
            border-radius: 10px; /* Rounded corners */
            padding: 20px; /* Padding inside review */
            width: 300px; /* Fixed width for reviews */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Subtle shadow */
            flex-shrink: 0; /* Prevent shrinking */
            transition: transform 0.3s; /* Animation for hover */
        }

        .review-container:hover {
            transform: translateY(-5 px); /* Lift effect on hover */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); /* Deeper shadow on hover */
        }

        .image-wrapper {
            text-align: center; /* Center the reviewer image */
            margin-bottom: 10px; /* Space below image */
        }

        .reviewer-image {
            width: 80px; /* Fixed width for reviewer image */
            height: 80px; /* Fixed height for reviewer image */
            border-radius: 50%; /* Circular image */
            object-fit: cover; /* Cover the area */
        }

        .stars {
            color: #f39c12; /* Gold color for stars */
            margin-bottom: 10px; /* Space below stars */
        }

        .review-text {
            font-size: 1rem; /* Review text size */
            color: #666; /* Lighter text */
            margin-bottom: 10px; /* Space below review text */
            line-height: 1.5; /* Line height for readability */
        }

        .reviewer-name {
            font-weight: bold; /* Bold name */
            color: #333; /* Dark text */
        }

        .reviewer-role {
            color: #999; /* Lighter text for role */
        }

        @media (max-width: 768px) {
            .about {
                flex-direction: column; /* Stack image and content on smaller screens */
                align-items: center; /* Center items */
            }

            .about .image {
                margin-right: 0; /* Remove margin on smaller screens */
                margin-bottom: 20px; /* Space below image */
            }

            .reviews-slider {
                flex-direction: column; /* Stack reviews on smaller screens */
                align-items: center; /* Center items */
            }
        }
    </style>
</head>

<body>
<!-- About Section Starts -->
<section class="about">
    <div class="image">
        <img src="https://logout.world/media/event/1082/Tripper_Trails-Gokarna_trip-_Beach_trek-_Weekend_trip_8_HSVDQ3j.JPG" alt="Beach Trek">
    </div>
    <div class="content">
        <h3>Why choose us?</h3>
        <p>Our beach treks offer you an unforgettable experience, combining stunning coastal views, fresh ocean air, and a chance to explore hidden beaches. Whether you're seeking adventure or relaxation, our trips are designed to cater to everyone who loves the beach life.</p>
        <p>We ensure that each trek is led by experienced guides who are passionate about the environment and dedicated to making your experience safe and memorable. Join us for a weekend getaway or an extended trip to unwind, connect with nature, and make lasting memories on some of the most beautiful beaches in the region.</p>
        
        <div class="icons-container">
            <div class="icons">
                <i class="fas fa-map"></i>
                <span>Top destination</span>
            </div>
            <div class="icons">
                <i class="fas fa-hand-holding-usd"></i>
                <span>Affordable price</span>
            </div>
            <div class="icons">
                <i class="fas fa-headset"></i>
                <span>24/7 guide services</span>
            </div>
        </div>
    </div>
</section>

<!-- Reviews Section Start -->
<section class="customer-testimonials">
  <div class="testimonials-header">
    <h2>What Our Customers Say</h2>
    <p>Discover the experiences of those who traveled with us!</p>
  </div>
  <div class="reviews-slider">
    <!-- Review 1 -->
    <div class="review-container">
      <div class="image-wrapper">
        <img src="https://media.istockphoto.com/id/589958694/photo/portrait-of-a-trendy-young-man-in-the-city.jpg?s=612x612&w=is&k=20&c=oWGwL1kO0sN84rlsIYgmi6174m2YhwyM3HcOQJEtOXU=" alt="Reviewer Image" class="reviewer-image" />
      </div>
      <div class="stars">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
      </div>
      <p class="review-text">
        "The historical tour of Rome was fantastic! I learned so much and loved every minute of it. The guide, John, was extremely knowledgeable and kept the entire group engaged. I can't wait to book my next trip!"
      </p> <h3 class="reviewer-name">James L.</h3>
      <span class="reviewer-role">History Enthusiast</span>
    </div>

    <!-- Review 2 -->
    <div class="review-container">
      <div class="image-wrapper">
        <img src="https://media.istockphoto.com/id/855413388/photo/theres-so-much-to-see.jpg?s=612x612&w=0&k=20&c=0pYgKJ46BH8ziQ31CMEQFSNNcvJ5P1RIwiKMHNWDr1A=" alt="Reviewer Image" class="reviewer-image" />
      </div>
      <div class="stars">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star-half-alt"></i>
        <i class="fas fa-star"></i>
      </div>
      <p class="review-text">
        "The adventure tour was unforgettable! We went to breathtaking locations and experienced amazing activities. Our guide made sure everyone had a great time and felt comfortable. Highly recommend this experience to anyone looking for adventure!"
      </p>
      <h3 class="reviewer-name">Sophia D.</h3>
      <span class="reviewer-role">Adventure Seeker</span>
    </div>

    <!-- Review 3 -->
    <div class="review-container">
      <div class="image-wrapper">
        <img src="https://media.istockphoto.com/id/478428832/photo/pointing-copy-space.jpg?s=612x612&w=is&k=20&c=HsIEMFaoFwsOjVxVettA0B8L_4nZpB58e4CNR-daQfU=" alt="Reviewer Image" class="reviewer-image" />
      </div>
      <div class="stars">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
      </div>
      <p class="review-text">
        "I had an amazing experience during my tour. The guides were friendly, and the locations we visited were breathtaking. The perfect balance of sightseeing and relaxation. It was truly an unforgettable trip!"
      </p>
      <h3 class="reviewer-name">Mark P.</h3>
      <span class="reviewer-role">Explorer</span>
    </div>

    <!-- Review 4 -->
    <div class="review-container">
      <div class="image-wrapper">
        <img src="https://static.vecteezy.com/system/resources/thumbnails/038/439/918/small/ai-generated-man-with-hat-and-backpack-on-cliff-photo.jpeg" alt="Reviewer Image" class="reviewer-image" />
      </div>
      <div class="stars">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
      </div>
      <p class="review-text">
        "The tour exceeded my expectations. John, the tour guide, was very friendly, knowledgeable, and professional. He made sure the group was having a great time, and I learned a lot. I’d book another tour with him again without hesitation!"
      </p>
      <h3 class="reviewer-name">Emily R.</h3>
      <span class="reviewer-role">Tourist</span>
    </div>

    <!-- Review 5 -->
    <div class="review-container">
      <div class="image-wrapper">
        <img src="https://static.vecteezy.com/system/resources/thumbnails/029/334/192/small/ai-generative-back-view-young-tourist-man-in-summer-dress-and-hat-standing-on-beautiful-sandy-beach-enjoying-free-photo.jpg" alt="Reviewer Image" class="reviewer-image" />
      </div>
      <div class="stars">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
      </div>
      <p class="review-text">
        "From the moment we arrived, the tour was seamless. Our guide, John, was friendly and offered fantastic insights into every site we visited. I highly recommend this tour for anyone interested in exploring Rome’s rich history!"
      </p>
      <h3 class="reviewer-name">John T.</h3>
      <span class="reviewer-role">History Buff</span>
    </div>
  </div>
</section>
<!-- About Section End -->  

<div class="heading" style="background:url(), no-repeat">
</div>

<?php
  include "includes/user_footer.php";
?>
</body>
</html>