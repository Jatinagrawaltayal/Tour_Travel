<?php
session_start();

// अगर session या previous page से data मिले तो use करो (optional)
$booking_id = $_SESSION['booking_id'] ?? "TRX" . rand(100000,999999);
$name = $_SESSION['name'] ?? "Guest User";
$package_name = $_SESSION['package_name'] ?? "Tour Package";
$amount = $_SESSION['amount'] ?? "0";
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Booking Confirmation</title>

<style>
body{
margin:0;
font-family:'Segoe UI', sans-serif;
background:linear-gradient(135deg,#667eea,#764ba2);
display:flex;
justify-content:center;
align-items:center;
height:100vh;
}

/* Card */
.container{
background:#fff;
border-radius:15px;
box-shadow:0 15px 35px rgba(0,0,0,0.2);
padding:35px;
text-align:center;
max-width:520px;
width:90%;
animation:fadeIn 1s ease;
}

/* Tick Animation */
.checkmark{
font-size:65px;
color:#2ecc71;
animation:pop 0.5s ease;
}

/* Heading */
h1{
color:#2ecc71;
margin:10px 0;
}

/* Booking ID */
.booking{
background:#f1f2f6;
padding:12px;
border-radius:8px;
margin:15px 0;
font-weight:bold;
}

/* Info */
.info{
text-align:left;
margin-top:20px;
line-height:1.8;
font-size:15px;
}

/* Buttons */
.btn{
display:inline-block;
margin:10px 5px;
padding:12px 20px;
background:#3498db;
color:white;
text-decoration:none;
border-radius:6px;
transition:0.3s;
}
.btn:hover{
background:#2980b9;
}

/* Secondary button */
.btn2{
background:#2ecc71;
}
.btn2:hover{
background:#27ae60;
}

/* Countdown */
.countdown{
margin-top:15px;
font-size:14px;
color:#555;
}

/* Animations */
@keyframes fadeIn{
from{opacity:0; transform:translateY(20px);}
to{opacity:1; transform:translateY(0);}
}
@keyframes pop{
0%{transform:scale(0);}
100%{transform:scale(1);}
}
</style>

</head>

<body>

<div class="container">

<div class="checkmark">✔</div>

<h1>Booking Confirmed!</h1>

<p>Your tour has been successfully booked 🎉</p>

<div class="booking">
Booking ID: <?php echo $booking_id; ?>
</div>

<div class="info">
<p><strong>Name:</strong> <?php echo $name; ?></p>
<p><strong>Package:</strong> <?php echo $package_name; ?></p>
<p><strong>Total Amount:</strong> ₹<?php echo $amount; ?></p>
<p><strong>Status:</strong> Confirmed (Cash on Arrival)</p>
</div>

<!-- Buttons -->
<a href="home.php" class="btn">🏠 Go to Home</a>
<a href="#" onclick="window.print()" class="btn btn2">🖨 Print</a>

<div class="countdown">
Redirecting to home in <span id="timer">10</span> seconds...
</div>

</div>

<script>
// Countdown redirect
let time = 10;
let timer = document.getElementById("timer");

let countdown = setInterval(()=>{
time--;
timer.innerHTML = time;

if(time <= 0){
clearInterval(countdown);
window.location.href="home.php";
}
},1000);
</script>

</body>
</html>