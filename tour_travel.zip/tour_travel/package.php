<?php
include "includes/user_header.php";
// include '../database/conn.php'; // Ensure you include your database connection

// Fetch packages from the database
$query = "SELECT * FROM packages";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>Go Trip</title>
    <style>
        .packages {
            padding: 50px 20px;
            text-align: center;
        }

        .packages h1 {
            font-size: 2.5rem;
            margin-bottom: 40px;
            color: #333; /* Dark text for contrast */
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .packages .box-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); /* Responsive grid */
            gap: 20px; /* Space between boxes */
            max-width: 1200px;
            margin: 0 auto; /* Center the container */
        }

        .packages .box-container .box {
            background-color: #fff; /* White background for boxes */
            border-radius: 10px; /* Rounded corners */
            overflow: hidden; /* Hide overflow */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* Subtle shadow */
            transition: transform 0.3s, box-shadow 0.3s; /* Animation for hover effect */
            display: flex;
            flex-direction: column; /* Stack children vertically */
            height: 100%; /* Ensure the box takes full height */
        }

        .packages .box-container .box:hover {
            transform: translateY(-5px); /* Lift effect on hover */
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2); /* Deeper shadow on hover */
        }

        .packages .box-container .box .image img {
            width: 100%; /* Full width */
            height: 200px; /* Fixed height */
            object-fit: cover; /* Cover the area */
        }

        .packages .box-container .box .content {
            padding: 20px; /* Padding inside the box */
            flex-grow: 1; /* Allow content to grow and take available space */
            display: flex;
            flex-direction: column; /* Stack content vertically */
            justify-content: space-between; /* Space out content */
        }

        .packages .box-container .box .content h3 {
            font-size: 1.8rem; /* Title size */
            margin-bottom: 10px; /* Space below title */
            color: #333; /* Dark text */
        }

        .packages .box-container .box .content p {
            font-size: 1rem; /* Description size */
            color: #666; /* Lighter text */
            margin-bottom: 20px; /* Space below description */
        }

        .packages .box-container .box .btn {
            display: inline-block; /* Button display */
            padding: 10px 20px; /* Button padding */
            background-color: #3498db; /* Main color */
            color: #fff; /* White text */
            border: none; /* No border */
            border-radius: 5px; /* Rounded corners */
            text-decoration: none; /* No underline */
            transition: background-color 0.3s; /* Animation for hover */
            margin-top: 10px; /* Space above buttons */
            margin-right: 30px;
        }

        .packages .box-container .box .btn:hover {
            background-color: #2980b9; /* Darker shade on hover */
        }

        .load-more {
            margin-top: 40px; /* Space above load more button */
        }

        .load-more .btn {
            padding: 12px 30px; /* Button padding */
            font-size: 1.2rem; /* Button font size */
            background-color: #e74c3c; /* Accent color */
            border-radius: 5px; /* Rounded corners */
            color: #fff; /* White text */
            border: none; /* No border */
            cursor: pointer; /* Pointer cursor */
            transition: background-color 0.3s; /* Animation for hover */
        }

        .load-more .btn:hover {
            background-color: #c0392b; /* Darker shade on hover */
        }
    </style>
</head>

<body>
    <!-- Package Section Start -->
    <section class="packages">
        <h1 class="heading-title">Top Destinations</h1>
        <div class="box-container">
            <?php
            if ($result->num_rows > 0) {
                // Output data of each row
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="box">';
                    echo '<div class="image">';
                    echo '<img src="admin/' . htmlspecialchars($row['image']) . '" alt="' . htmlspecialchars($row['package_name']) . '">';
                    echo '</div>';
                    echo '<div class="content">';
                    echo '<h3>' . htmlspecialchars($row['package_name']) . '</h3>';
                    echo '<p>' . htmlspecialchars($row['description']) . '</p>';
                    echo '<div class="button-container">';
                    echo '<a href="package_details.php?id=' . $row['package_id'] . '" class="btn">View More</a>';
                    echo '<a href="book.php?id=' . $row["package_id"] . '&name=' . urlencode($row["package_name"]) . '&price_adult=' . $row["price_adult"] . '&price_infant=' . $row["price_infant"] . '" class="btn">Book Now</a>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo '<p>No packages available at the moment.</p>';
            }
            ?>
        </div>

        <!-- <div class="load-more">
            <button class="btn" aria-label="Load more content">Load More</button>
        </div> -->
    </section>
    <!-- Package Section End -->

    <?php
    include "includes/user_footer.php";
    ?>
</body>
</html>

<?php
$conn->close(); // Close the database connection
?>