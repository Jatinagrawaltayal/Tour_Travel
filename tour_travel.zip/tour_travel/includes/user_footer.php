<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        /* Footer Section */
        .footer {
            background-color: #333 !important;
            color: #fff;
            padding: 50px 20px;
            text-align: center;
        }

        .footer .box-container {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            max-width: 1200px;
            margin: 0 auto;
        }

        .footer .box {
            width: 22%;
            margin-bottom: 30px;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .footer .box:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
        }

        .footer .box h3 {
            font-size: 20px;
            color: #fff;
            margin-bottom: 15px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .footer .box ul {
            list-style-type: none;
            padding: 0;
        }

        .footer .box ul li {
            margin-bottom: 10px;
        }

        .footer .box ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 16px;
            transition: color 0.3s;
        }

        .footer .box ul li a:hover {
            color: #ffd700; /* Gold color on hover */
        }

        .footer-bottom {
    background-color: #222; /* Dark background for contrast */
    padding: 20px 0; /* Adequate padding for spacing */
    font-size: 14px; /* Font size for the text */
    text-align: center; /* Center the text */
    color: #fff; /* White text color */
    position: relative; /* For positioning */
    box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.5); /* Subtle shadow for depth */
}

.footer-bottom p {
    margin: 0; /* Remove default margin */
    font-weight: 300; /* Lighter font weight for a softer look */
}

        /* Responsive Design */
        @media (max-width: 768px) {
            .footer .box-container {
                flex-direction: column;
                align-items: center;
            }

            .footer .box {
                width: 80%;
                margin-bottom: 20px;
            }
            .footer-bottom {
        font-size: 12px; /* Smaller font size on mobile */
    }
        }
    </style>
</head>
<body>
    
    <!-- Footer Section -->
    <section class="footer">
        <div class="box-container">
            <div class="box">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="home.php"><i class="fas fa-angle-right"></i> Home</a></li>
                    <li><a href="about.php"><i class="fas fa-angle-right"></i> About</a></li>
                    <li><a href="package.php"><i class="fas fa-angle-right"></i> Package</a></li>
                    <li><a href="book.php"><i class="fas fa-angle-right"></i> Book</a></li>
                </ul>
            </div>

            <div class="box">
                <h3>Extra Links</h3>
                <ul>
                    <li><a href="#"><i class="fas fa-angle-right"></i> Ask Question</a></li>
                    <li><a href="#"><i class="fas fa-angle-right"></i> About Us</a></li>
                    <li><a href="#"><i class="fas fa-angle-right"></i> Privacy Policy</a></li>
                    <li><a href="#"><i class="fas fa-angle-right"></i> Terms of Use</a></li>
                </ul>
            </div>

            <div class="box">
                <h3>Contact Info</h3>
                <ul>
                    <li><a href="#"><i class="fas fa-phone"></i> +123-456-789</a></li>
                    <li><a href="#"><i class="fas fa-phone"></i> +111-222-333</a></li>
                    <li><a href="#"><i class="fas fa-envelope"></i> gotrip@gmail.com</a></li>
                    <li><a href="#"><i class="fas fa-map-marker-alt"></i > Mumbai, India - 400104</a></li>
                </ul>
            </div>

            <div class="box">
                <h3>Follow Us</h3>
                <ul>
                    <li><a href="#"><i class="fab fa-facebook-f"></i> Facebook</a></li>
                    <li><a href="#"><i class="fab fa-twitter"></i> Twitter</a></li>
                    <li><a href="#"><i class="fab fa-instagram"></i> Instagram</a></li>
                    <li><a href="#"><i class="fab fa-linkedin"></i> LinkedIn</a></li>
                </ul>
            </div>
        </div>
    </section>

    <!-- Footer Bottom Section -->
    <div class="footer-bottom">
        <p>&copy; 2025 GoTrip. All rights reserved.</p>
    </div>

</body>
</html>