<?php
include "database/conn.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>User Header</title>
    <style>
        /* Global Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: #f9f9f9; /* Light white */
        }

        /* Header */
        .header {
            position: sticky;
            top: 0;
            z-index: 1000;
            background: linear-gradient(90deg, #3498db, #2c3e50); /* Main and secondary colors */
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1.5rem 2rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            transition: background-color 0.3s, box-shadow 0.3s;
        }

        .header:hover {
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.4);
        }

        .nav-bar {
            display: flex;
            align-items: center; /* Center items vertically */
            gap: 2rem;
        }

        .nav-bar a {
            color: #fff; /* White */
            text-decoration: none;
            font-size: 1.2rem;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            transition: background 0.3s, color 0.3s;
        }

        .nav-bar a:hover {
            background: #e74c3c; /* Accent color */
            color: #fff; /* White */
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        /* Profile Dropdown */
        .profile-dropdown {
            position: relative; /* Position relative for dropdown */
        }

        .profile-dropdown-content {
            display: none; /* Hidden by default */
            position: absolute; /* Position it absolutely */
            background-color: #fff; /* White background */
            min-width: 200px; /* Minimum width */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Shadow for depth */
            z-index: 1; /* Ensure it is above other content */
        }

        .profile-dropdown-content a {
            color: #333; /* Dark text */
            padding: 12px 16px; /* Padding for dropdown items */
            text-decoration: none; /* No underline */
            display: block; /* Block display */
        }

        .profile-dropdown-content a:hover {
            background-color: #f1f1f1; /* Light gray on hover */
            color: crimson;
        }

        .profile-dropdown:hover .profile-dropdown-content {
            display: block; /* Show dropdown on hover */
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            animation: slideInLeft 1s ease-out;
            display: flex;
            align-items: center;
            font-family: agbalumo;
        }
        .logo a {
            text-decoration: none;
            color: #fff;
        }
        .logo i {
            margin-right: 10px;
            color: crimson;
            position: relative;
            font-size: 26px;
            text-shadow: 2px 2px 0 green, 4px 4px 0 yellow;
        }
        /* Hover Effect for Logo */
        .logo:hover {
            transform: scale(1.1);
            transition: transform 0.3s ease-in-out;
            cursor: pointer;
        }

        /* Welcome Message */
        .welcome-message {
            color: gold;
            font-size: 1.2rem;
            padding: 0.5rem 1rem; /* Padding to match other items */
            border-radius: 5px; /* Rounded corners */
            transition: background 0.3s, color 0.3s; /* Transition for hover */
        }

        .nav-bar .welcome-message:hover {
            background: none;
            color: #fff; /* White text on hover */
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3); /* Shadow effect */
        }
    </style>
</head>
<body>
    
    <!-- Header Section -->
    <section class="header">
        <div class="logo">
           <a href="home.php" alt="logo"><i class="fas fa-campground"></i>GoTripZ</a>
        </div>
        <nav class="nav-bar">
            <a href="home.php"><i class="fas fa-home"></i> Home</a>
            <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
            <a href="package.php"><i class="fas fa-box"></i> Packages</a>
            <a href="feedback.php"><i class="fas fa-comments"></i> Feedback</a>
            <div class="profile-dropdown">
                <?php
                if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true) {
                    // Display welcome message and dropdown
                    $username = $_SESSION['username'];
                    echo '<a href="#" class="welcome-message"><i class="fas fa-user"></i> Welcome, ' . htmlspecialchars($username) . '!</a>';
                    echo '<div class="profile-dropdown-content">';
                    echo '<a href="user_profile.php"><i class="fas fa-user-cog"></i> Profile Settings</a>';
                    // echo '<a href="customer_support.php"><i class="fas fa-headset"></i> Customer Support</a>';
                    echo '<a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>';
                    echo '</div>';
                } else {
                    echo '<a href="user_login_register.php"><i class="fas fa-sign-in-alt"></i> Login</a>';
                }
                ?>
            </div>
        </nav>
        <!-- <div id="menu-btn" class="fas fa-bars"></div> -->
    </section>

</body>
</html>