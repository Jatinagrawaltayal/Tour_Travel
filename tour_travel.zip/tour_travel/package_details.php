<?php
include "includes/user_header.php"; // Include your header or session management

// Check if the package ID is set in the URL
if (isset($_GET['id'])) {
    $package_id = $_GET['id'];

    // Fetch package details from the database
    $stmt = $conn->prepare("SELECT * FROM packages WHERE package_id = ?");
    $stmt->bind_param("i", $package_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $package = $result->fetch_assoc();
    } else {
        echo "<script>alert('Package not found.'); window.location.href='packages.php';</script>";
        exit();
    }
} else {
    echo "<script>alert('Invalid package ID.'); window.location.href='packages.php';</script>";
    exit();
}

// Fetch itinerary details for the package
$itinerary_stmt = $conn->prepare("SELECT day_number, description FROM itineraries WHERE package_id = ? ORDER BY day_number");
$itinerary_stmt->bind_param("i", $package_id);
$itinerary_stmt->execute();
$itinerary_result = $itinerary_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($package['package_name']); ?> - Package Details</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .image img {
            width: 100%;
            height: auto;
            border-radius: 10px;
        }

        .details {
            margin-top: 20px;
            display: flex;
            flex-direction: column;
            gap: 20px; /* Space between detail cards */
        }

        .detail-card {
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .detail-card h4 {
            margin: 0 0 10px;
            color: #333;
        }

        .detail-card p {
            margin: 0;
            color: #666;
            font-size: 1.1rem;
        }

        .price-duration {
            display: flex;
            justify-content: space-between;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-top: 5px;
            background-color: #f9f9f9;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .price-duration h4 {
            margin: 0 0 10px;
            color: #333;
        }

        .price-duration p {
            margin: 0;
            color: #666;
            font-size: 1.1rem;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s;
            margin-top: 20px;
            width: fit-content;
        }

        .btn:hover {
            background-color: #2980b9;
        }

        .inclusions, .exclusions, .age-restrictions, .contact-info {
            margin-top: 20px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
        }

        .inclusions h4, .exclusions h4, .age-restrictions h4, .contact-info h4 {
            margin-bottom: 10px;
            color: #333;
        }

        .itinerary {
            margin-top: 20px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
        }

        .itinerary h4 {
            margin-bottom: 10px;
            color: #333;
        }

        .timeline {
            position: relative;
            padding: 20px 0;
        }

        .timeline::after {
            content: '';
            position: absolute;
            left: 10px;
            top: 0;
            height: 100%;
            border-left: 2px solid crimson;
            transform: translateX(-50%);
        }

        .timeline-item {
            position: relative;
            margin: 20px 0;
            padding-left: 30px;
        }

        .timeline-item::before {
            content: '';
            position: absolute;
            left: 10px;
            top: 0;
            width: 15px;
            height: 15px;
            background: black;
            border-radius: 50%;
            transform: translateX(-50%);
        }

        .timeline-item h5 {
            margin: 0;
            color: #333;
        }

        .timeline-item p {
            margin: 5px 0 0;
            color: #666;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1><?php echo htmlspecialchars($package['package_name']); ?></h1>
        <div class="image">
            <img src="admin/<?php echo htmlspecialchars($package['image']); ?>" alt="<?php echo htmlspecialchars($package['package_name']); ?>">
        </div>
        <div class="details">
            <div class="detail-card">
                <h4>Description</h4>
                <p><?php echo htmlspecialchars($package['description']); ?></p </div>
            <div class="price-duration">
                <div>
                    <h4>Adult (12 yrs +)</h4>
                    <p>₹<?php echo htmlspecialchars($package['price_adult']); ?></p>
                </div>
                <div>
                    <h4>Child (0 - 11 yrs)</h4>
                    <p>₹<?php echo htmlspecialchars($package['price_infant']); ?></p>
                </div>
            </div>
            <div class="detail-card">
                <h4>Duration</h4>
                <p><?php echo htmlspecialchars($package['duration']); ?> days</p>
            </div>
        </div>

        <div class="inclusions">
            <h4>Inclusions:</h4>
            <p><?php echo htmlspecialchars($package['inclusions']); ?></p>
        </div>

        <div class="exclusions">
            <h4>Exclusions:</h4>
            <p><?php echo htmlspecialchars($package['exclusions']); ?></p>
        </div>

        <div class="age-restrictions">
            <h4>Age Restrictions:</h4>
            <p><?php echo htmlspecialchars($package['age_restrictions']); ?></p>
        </div>

        <div class="contact-info">
            <h4>Contact Information:</h4>
            <p><?php echo htmlspecialchars($package['contact_info']); ?></p>
        </div>

        <div class="itinerary">
            <h4>Itinerary:</h4>
            <?php if ($itinerary_result->num_rows > 0): ?>
                <div class="timeline">
                    <?php while ($itinerary = $itinerary_result->fetch_assoc()): ?>
                        <div class="timeline-item">
                            <h5>Day <?php echo htmlspecialchars($itinerary['day_number']); ?></h5>
                            <p><?php echo htmlspecialchars($itinerary['description']); ?></p>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <p>No itinerary available for this package.</p>
            <?php endif; ?>
        </div>

        <a href="book.php?id=<?php echo $package['package_id']; ?>&name=<?php echo urlencode($package['package_name']); ?>&price_adult=<?php echo $package['price_adult']; ?>&price_infant=<?php echo $package['price_infant']; ?>" class="btn">Book Now</a>
    </div>

</body>

</html>

<?php
$itinerary_stmt->close();
$conn->close(); // Close the database connection
?>