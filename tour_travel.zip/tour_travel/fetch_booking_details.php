<?php
// include '../database/conn.php'; // Ensure you include your database connection

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_GET['booking_id'])) {
    $booking_id = intval($_GET['booking_id']);
    
    // Prepare and execute the SQL statement to fetch booking details
    $stmt = $conn->prepare("SELECT * FROM bookings WHERE book_id = ?");
    if ($stmt === false) {
        die(json_encode(["error" => "Error preparing statement: " . $conn->error]));
    }
    
    $stmt->bind_param("i", $booking_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $bookingDetails = $result->fetch_assoc();
        echo json_encode($bookingDetails);
    } else {
        echo json_encode(["error" => "No booking found."]);
    }

    $stmt->close();
} else {
    echo json_encode(["error" => "No booking ID provided."]);
}
?>