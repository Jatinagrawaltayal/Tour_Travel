<?php
include "includes/user_header.php";

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header("Location: user_login_register.php");
    exit();
}

// Get the user ID from the session
$user_id = $_SESSION['user_id'];

// Prepare and execute the SQL statement to fetch user details
$stmt = $conn->prepare("SELECT username, email, phone, address FROM users WHERE user_id = ?");
if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("i", $user_id); // Bind the user ID as an integer
$stmt->execute();
$result = $stmt->get_result();

// Check if the user exists
if ($result->num_rows > 0) {
    // Fetch user data
    $user = $result->fetch_assoc();
    $username = $user['username'];
    $email = $user['email'];
    $phone = $user['phone'];
    $address = $user['address'];
} else {
    // Handle case where user is not found
    echo "User  not found.";
    exit();
}

// Close the statement
$stmt->close();

// Handle form submission for updating user details
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $new_phone = htmlspecialchars($_POST['phone']);
    $new_address = htmlspecialchars($_POST['address']);

    // Prepare and execute the SQL statement to update user details
    $update_stmt = $conn->prepare("UPDATE users SET phone = ?, address = ? WHERE user_id = ?");
    if ($update_stmt === false) {
        die("Error preparing update statement: " . $conn->error);
    }
    $update_stmt->bind_param("ssi", $new_phone, $new_address, $user_id);

    if ($update_stmt->execute()) {
        echo "<script>alert('Profile updated successfully!'); window.location.href='user_profile.php';</script>";
        exit();
    } else {
        echo "Error updating profile: " . $update_stmt->error;
    }

    // Close the update statement
    $update_stmt->close();
}


// Handle form submission for changing password
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Fetch the current password from the database
    $stmt = $conn->prepare("SELECT password FROM users WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        // Verify the current password
        if (password_verify($current_password, $user['password'])) {
            // Check if new password and confirm password match
            if ($new_password === $confirm_password) {
                // Hash the new password
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

                // Update the password in the database
                $update_stmt = $conn->prepare("UPDATE users SET password = ? WHERE user_id = ?");
                $update_stmt->bind_param("si", $hashed_password, $user_id);

                if ($update_stmt->execute()) {
                    // echo "<script>alert('Password updated successfully!');</script>";
                    echo "<script>alert('Password updated successfully!'); window.location.href='user_profile.php';</script>";
                    exit();
                } else {
                    echo "Error updating password: " . $update_stmt->error;
                }

                $update_stmt->close();
            } else {
                echo "<script>alert('New password and confirm password do not match.');</script>";
            }
        } else {
            echo "<script>alert('Current password is incorrect.');</script>";
        }
    } else {
        echo "User  not found.";
    }

    $stmt->close();
}

// Fetch booking history
$bookings_stmt = $conn->prepare("SELECT book_id, location, departure_date, total_amount FROM bookings WHERE user_id = ?");
if ($bookings_stmt === false) {
    die("Error preparing bookings statement: " . $conn->error);
}
$bookings_stmt->bind_param("i", $user_id);
$bookings_stmt->execute();
$bookings_result = $bookings_stmt->get_result();

// Initialize booking details
$bookingDetails = null;

// Check if a booking ID is provided in the URL
if (isset($_GET['booking_id'])) {
    $booking_id = $_GET['booking_id'];
    $booking_stmt = $conn->prepare("SELECT * FROM bookings WHERE book_id = ?");
    $booking_stmt->bind_param("i", $booking_id);
    $booking_stmt->execute();
    $booking_details_result = $booking_stmt->get_result();

    if ($booking_details_result->num_rows > 0) {
        $bookingDetails = $booking_details_result->fetch_assoc();
    } else {
        $bookingDetails = ["error" => "No booking found."];
    }

    $booking_stmt->close();
}

// Fetch cancelled bookings
$cancelled_bookings_stmt = $conn->prepare("SELECT * FROM cancelled_bookings WHERE user_id = ?");
if ($cancelled_bookings_stmt === false) {
    die("Error preparing cancelled bookings statement: " . $conn->error);
}
$cancelled_bookings_stmt->bind_param("i", $user_id);
$cancelled_bookings_stmt->execute();
$cancelled_bookings_result = $cancelled_bookings_stmt->get_result();

// Check if a cancelled booking ID is provided in the URL
if (isset($_GET['cancelled_booking_id'])) {
    $cancelled_booking_id = intval($_GET['cancelled_booking_id']);
    $booking_stmt = $conn->prepare("SELECT * FROM cancelled_bookings WHERE book_id = ? AND user_id = ?");
    $booking_stmt->bind_param("ii", $cancelled_booking_id, $user_id);
    $booking_stmt->execute();
    $booking_details_result = $booking_stmt->get_result();

    if ($booking_details_result->num_rows > 0) {
        $bookingDetails = $booking_details_result->fetch_assoc();
    } else {
        $bookingDetails = ["error" => "No cancelled booking found."];
    }

    $booking_stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <style>
body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9f9f9; /* Light background */
            color: #333; /* Dark text */
            padding: 20px;
        }

        .container {
            max-width: 1200px; /* Max width for the profile card */
            margin: 0 auto; /* Center the card */
            background-color: #fff; /* White background for the card */
            border-radius: 10px; /* Rounded corners */
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); /* Subtle shadow */
            padding: 30px; /* Padding inside the card */
            margin-top: 2rem;
            margin-bottom: 2rem;
        }

        h1 {
            text-align: center; /* Center the title */
            color: #3498db; /* Main color */
            margin-bottom: 20px; /* Space below title */
        }

        .section {
            display: none; /* Hide all sections by default */
            margin-bottom: 30px; /* Space below sections */
            padding: 20px;
            border: 1px solid #ccc; /* Border around sections */
            border-radius: 5px; /* Rounded corners */
            background-color: #fdfdfd; /* Light background for sections */
        }

        .active {
            display: block; /* Show the active section */
        }

        .profile-info label {
            font-weight: bold; /* Bold labels */
            display: block; /* Block display for labels */
            margin-bottom: 5px; /* Space below labels */
        }

        .profile-info input {
            width: 100%; /* Full width for input fields */
            padding: 10px; /* Padding inside input */
            border: 1px solid #ccc; /* Border color */
            border-radius: 5px; /* Rounded corners */
            margin-bottom: 15px; /* Space below input fields */
            font-size: 1rem; /* Font size for input */
        }

        .btn {
            display: inline-block; /* Button display */
            padding: 10px 20px; /* Button padding */
            background-color: #3498db; /* Main color */
            color: #fff; /* White text */
            border: none; /* No border */
            border-radius: 5px; /* Rounded corners */
            text-decoration: none; /* No underline */
            font-size: 1.2rem; /* Button font size */
            transition: background-color 0.3s; /* Animation for hover */
            text-align: center; /* Center text */
        }

        .btn:hover {
            background-color: #2980b9; /* Darker shade on hover */
        }

        .nav-buttons {
            text-align: center; /* Center navigation buttons */
            margin-bottom: 20px; /* Space below navigation */
        }

/* Modal styles */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1000; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgba(0, 0, 0, 0.7); /* Dark background with opacity */
    backdrop-filter: blur(5px); /* Blur effect for the background */
    transition: opacity 0.3s ease; /* Smooth transition for modal */
}

.modal-content {
    background-color: #fff; /* White background for the modal */
    margin: 10% auto; /* Center the modal */
    padding: 20px;
    border-radius: 10px; /* Rounded corners */
    width: 80%; /* Could be more or less, depending on screen size */
    max-width: 600px; /* Max width for larger screens */
    max-height: 80vh; /* Maximum height of the modal */
    overflow-y: auto; /* Enable vertical scrolling if content exceeds max height */
    box-shadow: 0 4px 30px rgba(0, 0, 0, 0.2); /* Shadow for depth */
    animation: slideIn 0.5s; /* Animation for modal appearance */
}

@keyframes slideIn {
    from {
        transform: translateY(-50px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

.close {
    color: #aaa; /* Light gray color */
    float: right; /* Align to the right */
    font-size: 28px; /* Font size for close button */
    font-weight: bold; /* Bold text */
    transition: color 0.3s; /* Smooth transition for hover */
}

.close:hover,
.close:focus {
    color: #e74c3c; /* Change color on hover */
    text-decoration: none; /* No underline */
    cursor: pointer; /* Pointer cursor */
}

.modal-header {
    display: flex; /* Flexbox for header */
    justify-content: space-between; /* Space between items */
    align-items: center; /* Center items vertically */
    border-bottom: 1px solid #eee; /* Bottom border */
    padding-bottom: 10px; /* Space below header */
}

.modal-title {
    font-size: 1.5rem; /* Title font size */
    color: #3498db; /* Main color */
}

.modal-body {
    margin-top: 10px; /* Space above body */
}

/* Table styles */
table {
    width: 100%; /* Full width */
    border-collapse: collapse; /* Collapse borders */
    margin-top: 10px; /* Space above the table */
}

th, td {
    border: 1px solid #ddd; /* Light gray border */
    padding: 12px; /* Padding inside cells */
    text-align: left; /* Align text to the left */
}

th {
    background-color: #3498db; /* Header background color */
    color: white; /* Header text color */
    font-weight: bold; /* Bold text for headers */
}

tr:nth-child(even) {
    background-color: #f2f2f2; /* Light gray background for even rows */
}

tr:hover {
    background-color: #e0e0e0; /* Darker gray on hover */
    transition: background-color 0.3s; /* Smooth transition for hover */
}

tr td:nth-child(odd){
    font-weight: bold;
}

.modal-body p {
    margin: 0; /* Remove default margin for paragraphs */
    padding: 10px 0; /* Space above and below paragraphs */
}
    </style>
</head>
<body>

<div class="container">
    <h1>User Profile</h1>

    <div class="nav-buttons">
        <button class="btn" onclick="showSection('general-settings')">General Settings</button>
        <button class="btn" onclick="showSection('change-password')">Change Password</button>
        <button class="btn" onclick="showSection('booking-history')">Booking History</button>
        <button class="btn" onclick="showSection('cancelled-bookings')">Cancelled Bookings</button>
    </div>

    <!-- General Settings Section -->
    <div class="section" id="general-settings">
        <h2>General Settings</h2>
        <br>
        <form method="POST" action="">
            <div class="profile-info">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>" readonly>

                <label for="email">Email:</label>
                <input type="text" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" readonly>

                <label for="phone">Phone:</label>
                <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($phone); ?>" required>

                <label for="address">Address:</label>
                <input type="text" id="address" name="address" value="<?php echo htmlspecialchars($address); ?>" required>
            </div>
            <button type="submit" name="update_profile" class="btn">Save Changes</button>
        </form>
    </div>

    <!-- Password Change Section -->
    <div class="section" id="change-password">
        <h2>Change Password</h2>
        <br>
        <form method="POST" action="">
            <div class="profile-info">
                <label for="current_password">Current Password:</label>
                <input type="password" id="current_password" name="current_password" required>

                <label for="new_password">New Password:</label>
                <input type="password" id="new_password" name="new_password" required>

                <label for="confirm_password">Confirm New Password:</label>
                <input type="password" id="confirm_password" name="confirm_password" required>
            </div>
            <button type="submit" name="change_password" class="btn">Change Password</button>
        </form>
    </div>

<!-- Booking History Section -->
<div class="section" id="booking-history">
    <h2>Booking History</h2>
    <br>
    <?php if ($bookings_result->num_rows > 0): ?>
        <table style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr>
                    <th style="border: 1px solid #ccc; padding: 10px;">Booking ID</th>
                    <th style="border: 1px solid #ccc; padding: 10px;">Location</th>
                    <th style="border: 1px solid #ccc; padding: 10px;">Departure Date</th>
                    <th style="border: 1px solid #ccc; padding: 10px;">Total Amount</th>
                    <th style="border: 1px solid #ccc; padding: 10px;">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($booking = $bookings_result->fetch_assoc()): ?>
                    <tr>
                        <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($booking['book_id']); ?></td>
                        <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($booking['location']); ?></td>
                        <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($booking['departure_date']); ?></td>
                        <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($booking['total_amount']); ?></td>
                        <td style="border: 1px solid #ccc; padding: 10px;">
                            <a href="?booking_id=<?php echo htmlspecialchars($booking['book_id']); ?>" class="btn">View More</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No booking history found.</p>
    <?php endif; ?>
</div>

        <!-- Cancelled Bookings Section -->
        <div class="section" id="cancelled-bookings">
        <h2 style="color:red;">Cancelled Bookings</h2>
        <br>
        <?php if ($cancelled_bookings_result->num_rows > 0): ?>
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr>
                        <th style="border: 1px solid #ccc; padding: 10px;">Booking ID</th>
                        <th style="border: 1px solid #ccc; padding: 10px;">Package Name</th>
                        <th style="border: 1px solid #ccc; padding: 10px;">Cancellation Date</th>
                        <th style="border: 1px solid #ccc; padding: 10px;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($cancelled_booking = $cancelled_bookings_result->fetch_assoc()): ?>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($cancelled_booking['book_id']); ?></td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($cancelled_booking['location']); ?></td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($cancelled_booking['cancellation_date']); ?></td>
                            <td style="border: 1px solid #ccc; padding: 10px;">
                                <a href="?cancelled_booking_id=<?php echo htmlspecialchars($cancelled_booking['book_id']); ?>" class="btn">View More</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No cancelled bookings found.</p>
        <?php endif; ?>
    </div>

</div>

<!-- Modal for Booking Details -->
<div id="bookingModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <div id="modalContent">
            <?php if ($bookingDetails): ?>
                <?php if (isset($bookingDetails['error'])): ?>
                    <p><?php echo htmlspecialchars($bookingDetails['error']); ?></p>
                <?php else: ?>
                    <h2>Booking Details</h2>
                    <table style="width: 100%; border-collapse: collapse;">
                        <tr>
                            <th style="border: 1px solid #ccc; padding: 10px;">Field</th>
                            <th style="border: 1px solid #ccc; padding: 10px;">Information</th>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Booking ID</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['book_id']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">User  ID</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['user_id']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Name</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['name']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Email</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['email']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Phone</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['phone']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Address</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['address']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Location</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['location']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Adults</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['num_adults']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Children</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['num_children']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Departure Date</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['departure_date']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Total Amount</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['total_amount']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Booking Date</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['booking_date']); ?></td>
                        </tr>
                    </table>

                    <!-- Cancellation Note -->
                    <div style="margin-top: 20px; text-align: center;">
                        <p style="color: red; font-weight: bold;">Cancel within 24 hours of booking to receive 100% refund.</p>
                        <br>
                        <form action="cancel_booking.php" method="post" onsubmit="return confirmCancellation();">
                            <input type="hidden" name="booking_id" value="<?php echo htmlspecialchars($bookingDetails['book_id']); ?>">
                            <button type="submit" class="btn" style="background-color: red;">Cancel Booking</button>
                        </form>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <p>No booking details available.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal for Cancelled Booking Details -->
<div id="cancelledBookingModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeCancelledBookingModal()">&times;</span>
        <div id="cancelledModalContent">
            <?php if (isset($bookingDetails) && !isset($bookingDetails['error'])): ?>
                <h2>Cancelled Booking Details</h2>
                <table style="width: 100%; border-collapse: collapse;">
                    <tr>
                        <th style="border: 1px solid #ccc; padding: 10px;">Field</th>
                        <th style="border: 1px solid #ccc; padding: 10px;">Information</th>
                    </tr>
                    <tr>
                        <td style="border: 1px solid #ccc; padding: 10px;">Booking ID</td>
                        <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['book_id']); ?></td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid #ccc; padding: 10px;">Name</td>
                        <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['name']); ?></td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid #ccc; padding: 10px;">Package Name</td>
                        <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['location']); ?></td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid #ccc; padding: 10px;">Total Amount</td>
                        <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['total_amount']); ?></td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid #ccc; padding: 10px;">Booking Date</td>
                        <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['booking_date']); ?></td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid #ccc; padding: 10px;">Cancellation Date</td>
                        <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['cancellation_date']); ?></td>
                    </tr>
                </table>
            <?php else: ?>
                <p><?php echo isset($bookingDetails['error']) ? htmlspecialchars($bookingDetails['error']) : 'No details available.'; ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    function showSection(sectionId) {
        const sections = document.querySelectorAll('.section');
        sections.forEach(section => {
            section.classList.remove('active');
        });

        const activeSection = document.getElementById(sectionId);
        if (activeSection) {
            activeSection.classList.add('active');
        }
    }

    window.onload = function() {
        showSection('general-settings');

        // Check if booking_id is present in the URL
        const urlParams = new URLSearchParams(window.location.search);
        const bookingId = urlParams.get('booking_id');
        const cancelledBookingId = urlParams.get('cancelled_booking_id');
        if (bookingId) {
            const modal = document.getElementById("bookingModal");
            modal.style.display = "block"; // Show the modal
        } else if (cancelledBookingId) {
            const modal = document.getElementById("cancelledBookingModal");
            modal.style.display = "block"; // Show the modal
        }
    };

    function closeModal() {
        const modal = document.getElementById("bookingModal");
        modal.style.display = "none";
        history.pushState({}, document.title, window.location.pathname);
    }

    function closeCancelledBookingModal() {
        document.getElementById('cancelledBookingModal').style.display = 'none';
        history.pushState({}, document.title, window.location.pathname);
    }

    function confirmCancellation() {
        return confirm("Are you sure you want to cancel this booking?");
    }
</script>

<?php
include "includes/user_footer.php";
?>

</body>
</html>