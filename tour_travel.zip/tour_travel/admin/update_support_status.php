<?php
include "../database/conn.php";

if (isset($_POST['support_id'])) {
    $supportId = $_POST['support_id'];
    $query = "UPDATE cust_support SET status = 'Solved' WHERE support_id = '$supportId'";
    if ($conn->query($query) === TRUE) {
        echo 'success';
    } else {
        echo 'error';
    }
} else {
    echo 'error';
}
?>