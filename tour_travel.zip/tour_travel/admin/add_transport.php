<?php
include "includes/admin_header.php"; // Include your header or session management

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $transport_name = trim($_POST['transport_name']);

    // Insert the new transport into the transports table
    if (!empty($transport_name)) {
        $stmt = $conn->prepare("INSERT INTO transports (transport_name) VALUES (?)");
        $stmt->bind_param("s", $transport_name);
        $stmt->execute();
        $stmt->close();

        echo "<script>alert('Transport added successfully!'); window.location.href = 'add_transport.php';</script>";
    } else {
        echo "<script>alert('Please enter a transport name.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Transport</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Basic styles for the layout */
        body {
            display: flex;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        
        .container {
            max-width: 600px;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .container:hover {
            transform: scale(1.02);
        }
        h2 {
            text-align: center;
            color: #000;
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-top: 10px;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        input[type="text"] {
            margin: 5px 0 10px 0;
            padding: 10px;
            background: #f8f9fa;
            border: 1px solid #ced4da;
            border-radius: 5px;
            width: calc(100% - 22px);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        input[type="text"]:focus {
            border-color: #007bff;
            outline: none;
        }
        .edit-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background: crimson;
            color: white;
            font-weight: 600;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s ease-in-out;
            cursor: pointer;
        }
        .edit-button:hover {
            background: black;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>

<div class="container content" id="contentArea">
    <h2>Add Transport</h2>
    <form id="transportForm" method="POST" action="">
        <label for="transport_name">Transport Name:</label>
        <input type="text" id="transport_name" name="transport_name" placeholder="Enter transport name" required>

        <button type="submit" class="edit-button">Add Transport</button>
    </form>
</div>

<?php
include "includes/admin_footer.php"; // Include your footer
?>
</body>
</html>