<?php
include "../database/conn.php"; // Include your database connection

if (isset($_GET['package_id'])) {
    $package_id = intval($_GET['package_id']);

    // Query to count existing itinerary days for the selected package
    $stmt = $conn->prepare("SELECT COUNT(*) FROM itineraries WHERE package_id = ?");
    $stmt->bind_param("i", $package_id);
    $stmt->execute();
    $stmt->bind_result($existing_days);
    $stmt->fetch();
    $stmt->close();

    // Return the count as JSON
    echo json_encode(['existing_days' => $existing_days]);
}
?>