<?php
include "includes/admin_header.php"; // Include your header or session management

// Fetch all support requests
$query = "
    SELECT s.support_id, s.name, s.email, s.message, s.status 
    FROM cust_support s 
    JOIN users u ON s.user_id = u.user_id
";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Support Requests</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            display: flex;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        h1 {
            text-align: center;
            color: #000;
            margin-bottom: 20px;
        }

        .container {
            max-width: 1200px;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px animation: fadeIn 1s ease-in-out;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #000;
            color: white;
        }

        tr {
            color: crimson;
            font-weight: bold;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        .resolved-btn {
            background-color: green;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 5px;
        }

        .resolved-btn:hover {
            background-color: darkgreen;
        }

        .status-solved {
            color: green; /* Change text color to green for solved status */
        }
        .status-unsolved {
            color: red; /* Change text color to green for solved status */
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

<div class="container content" id="contentArea">
    <h1>All Support Requests</h1>
    <table>
        <thead>
            <tr>
                <th>S/N</th>
                <th>Name</th>
                <th>Email</th>
                <th>Message</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php 
                    $serialNumber = 1;
                    while ($row = $result->fetch_assoc()): 
                ?>
                    <tr>
                        <td><?php echo $serialNumber++; ?></td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><?php echo htmlspecialchars($row['message']); ?></td>
                        <td class="<?php echo ($row['status'] == 'Solved') ? 'status-solved' : 'status-unsolved'; ?>">
                            <?php echo htmlspecialchars($row['status']); ?>
                        </td>
                        <td>
                            <?php if ($row['status'] == 'Pending'): ?>
                                <button class="resolved-btn" data-support-id="<?php echo $row['support_id']; ?>">Resolved</button>
                            <?php else: ?>
                                <span>Already Resolved</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" style="text-align: center;">No support requests available.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<script>
$(document).ready(function() {
    $('.resolved-btn').on('click', function() {
        var supportId = $(this).data('support-id');
        $.ajax({
            type: 'POST',
            url: 'update_support_status.php',
            data: {support_id: supportId},
            success: function(response) {
                if (response == 'success') {
                    location.reload();
                } else {
                    alert('Error updating support status');
                }
            }
        });
    });
});
</script>

<?php
    include "includes/admin_footer.php";
?>
</body>
</html>