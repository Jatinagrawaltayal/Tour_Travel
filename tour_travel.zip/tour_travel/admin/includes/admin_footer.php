<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        body {
          display: flex;
          flex-direction: column;
            min-height: 100vh; /* Full height of the viewport */
            box-sizing: border-box;
        }

                .footer{
          max-width: 968px;
          margin: 0 auto;
          display: flex;
          justify-content: space-between;
          margin-left: 400px;
          margin-top: 5rem;
        }
        .social{
          display: flex;
          align-items: center;
          column-gap: 0.5rem;
          margin-left: 600px;
        }
        .social .bx{
          background: linear-gradient(145deg, crimson, #000);
          padding: 2px;
          font-size: 2rem;
          border-radius: 50%;
          border: 4px solid crimson;
          color: #fff;
          transition: all 0.5s ease-in-out;
        }
        .social .bx:hover{
          background: linear-gradient(145deg, #000, crimson);
          transform: scale(1.1);
        }

        .copyright{
          padding: 20px;
          text-align: center;
        }
        .copyright p{
            color: #fff;
        }
        .footer .logo i{
          text-shadow: 2px 2px 0 black, 4px 4px 0 black;
        }
    </style>
</head>
<body>

           <!-- Footer -->
           <section class="footer">
               <div class="logo">
               <a href="provider_dashboard.php" alt="logo"><i class="fas fa-campground"></i>GoTripZ</a>
                </div>
              <div class="social">
                <a href="#"><i class='bx bxl-facebook'></i></a>
                <a href="#"><i class='bx bxl-instagram'></i></a>
                <a href="#"><i class='bx bxl-twitter'></i></a>
                <a href="#"><i class='bx bxl-tiktok'></i></a>
              </div>
            </section>
            <!-- Copyright -->
            <div class="copyright">
               <p>&#169; GoTripZ All Rights Reserved.</p>
            </div>

</body>
</html>