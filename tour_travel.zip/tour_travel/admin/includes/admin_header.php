<?php
include '../database/conn.php'; 

// Check if the provider is logged in
if (!isset($_SESSION['admin_username'])) { 
    header("Location: admin_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="assets/css/admin_header.css"> <!-- Link to your CSS file -->
    <title></title>
    <style>
        /* Basic styles for the layout */
        body {
            display: flex; /* Use flexbox for layout */
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background: linear-gradient(to bottom, white, crimson);
            color: #fff;
        }
        a{
            text-decoration: none;
            color: white;
        }
        /* Custom Scroll Bar */
        html::-webkit-scrollbar {
            width: 0.6rem;
            background: linear-gradient(145deg, black, crimson);
        }
        html::-webkit-scrollbar-thumb {
            background: linear-gradient(290deg, white, crimson);
            border-radius: 5rem;
        }

        .sidebar {
            width: 250px; /* Width of the sidebar */
            background: linear-gradient(to bottom, black 0%, black 20%, crimson 100%); /* Sidebar background color */
            height: 100vh; /* Full height */
            position: fixed; /* Fixed position */
            overflow-y: auto; /* Scroll if needed */
            transition: width 0.3s; /* Smooth transition for width */
            margin-top: 3.6rem;
            color: #fff;
        }

        .sidebar h2 {
            color: white;
            text-align: center; /* Center the title */
            padding: 15px 0; /* Padding for the title */
            margin: 0; /* Remove default margin */
            background: crimson; /* Darker background for title */
        }

        .menu-item {
            padding: 15px 20px; /* Padding for menu items */
            cursor: pointer; /* Pointer cursor on hover */
            transition: all 0.3s ease-in-out; /* Smooth transition for background */
            display: flex; /* Flexbox for icon and text */
            align-items: center;
        }

        .menu-item i {
            margin-right: 10px; /* Space between icon and text */
        }

        .menu-item .chevron {
            margin-left: auto; /* Push chevron to the right */
        }

        .menu-item:hover {
            background-color: crimson; /* Darker background on hover */
        }

        .submenu {
            max-height: 0; /* Start with a max-height of 0 */
            overflow: hidden; /* Hide overflow */
            transition: max-height 0.3s ease; /* Smooth transition for max-height */
            padding-left: 20px; /* Indent submenu items */
        }

        .submenu-item {
            padding: 10px 20px; /* Padding for submenu items */
            cursor: pointer; /* Pointer cursor on hover */
            transition: all 0.3s ease-in-out; /* Smooth transition for background */
            display: flex; /* Flexbox for icon and text */
            align-items: center; /* Center items vertically */
        }

        .submenu-item i {
            margin-right: 10px; /* Space between icon and text */
        }

        .submenu-item:hover {
            background-color:crimson; /* Darker background on hover */
        }

        .content {
            margin-left: 20rem; /* Space for the sidebar */
            padding: 20px; /* Padding for content */
            flex-grow: 1; /* Allow content to grow */
            height: fit-content; /* Full height */
            overflow-y: auto; /* Scroll if needed */
            background-color: #ecf0f1; /* Light background for content */
            margin-top: 7rem;
            margin-right: 50px;
        }

        .admin-header {
            width: 100%; /* Full width for header */
            background: linear-gradient(to right, black 30%, crimson); /* Header background color */
            color: white; /* Text color */
            display: flex; /* Flexbox for header layout */
            justify-content: space-between; /* Space between logo and admin info */
            align-items: center; /* Center items vertically */
            padding: 10px 20px; /* Padding for header */
            position: fixed; /* Fixed position */
            top: 0; /* Align to top */
            z-index: 999;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            animation: slideInLeft 1s ease-out;
            display: flex;
            align-items: center;
            font-family: agbalumo;
        }
        .logo a {
            color: #fff;
        }
        .logo i {
            margin-right: 10px;
            color: #fff;
            position: relative;
            font-size: 26px;
            text-shadow: 2px 2px 0 crimson, 4px 4px 0 crimson;
        }
        /* Hover Effect for Logo */
.logo:hover {
    transform: scale(1.1);
    transition: transform 0.3s ease-in-out;
    cursor: pointer;
}
/* Animations */
@keyframes slideInLeft {
    from {
        transform: translateX(-100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

        .admin-info {
            display: flex; /* Flexbox for admin info layout */
            align-items: center; /* Center items vertically */
            margin-right: 3rem;
        }

        .admin-name {
            margin-right: 20px; /* Space between name and logout */
        }

        .logout {
            color: white; /* Logout link color */
            text-decoration: none; /* Remove underline */
            padding: 10px 10px; /* Padding for logout link */
            border-radius: 15px; /* Rounded corners */
            transition: all 0.3s ease-in-out; /* Smooth transition for background */
        }

        .logout:hover {
            background-color: #000; /* Change background on hover */
            color: #fff;
        }


        /* Popup styles */
        #popupBackdrop {
            display: none; /* Hidden by default */
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5); /* Semi-transparent background */
            backdrop-filter: blur(5px); /* Blur effect */
            z-index: 999; /* Ensure it is above other content */
            transition: all 0.5s ease-in-out;
        }
        .pop-card {
            width: 500px;
            height: 3rem;
            aspect-ratio: 1;
            border: 2px solid #fff;
            text-align: center;
            padding: 2rem 0 5rem 0;
            color: #fff;
            border-radius: 1rem;
            position: absolute; /* Position it absolutely */
            top: 50%; /* Center vertically */
            left: 50%; /* Center horizontally */
            transform: translate(-50%, -50%); /* Adjust for its own size */
            z-index: 1000; /* Ensure it is above the backdrop */
            transition: all 0.5s ease-in-out;
        }
        .pop-card i {
            font-size: 3rem;
        }
        .success {
            background-image: linear-gradient(to top right,rgb(52, 70, 14),rgb(2, 128, 10));
            box-shadow: 0 0 .7rem rgb(3, 71, 3);
        }
        .error {
            background-image: linear-gradient(to top right, #ff5773, #ff0000);
            box-shadow: 0 0 .7rem rgb(255, 0, 0);
        }
        .pop-card h2 {
            font-size: 3rem;
            text-transform: uppercase;
            letter-spacing: .5rem;
            margin: 1rem 0;
        }
        .pop-card p {
            font-size : 1.3rem;
        }

        /* Delete Popup Backdrop */
#deletePopupBackdrop {
    display: none; /* Hidden by default */
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.7); /* Darker semi-transparent background */
    backdrop-filter: blur(5px); /* Blur effect */
    z-index: 999; /* Ensure it is above other content */
    transition: all 0.5s ease-in-out;
}

/* Delete Popup Card */
.deletePopup {
    width: 400px; /* Set a fixed width */
    border-radius: 10px; /* Rounded corners */
    background: whitesmoke; /* White background */
    color: #333; /* Dark text color */
    font-weight: 800;
    text-align: center; /* Center text */
    padding: 20px; /* Padding inside the popup */
    position: absolute; /* Position it absolutely */
    top: 50%; /* Center vertically */
    left: 50%; /* Center horizontally */
    transform: translate(-50%, -50%); /* Adjust for its own size */
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3); /* Shadow for depth */
    transition: all 0.3s ease-in-out; /* Smooth transition */
}

/* Popup Title */
.deletePopup h2 {
    font-size: 24px; /* Font size for title */
    margin-bottom: 10px; /* Space below title */
}

/* Popup Message */
.deletePopup p {
    font-size: 16px; /* Font size for message */
    margin-bottom: 20px; /* Space below message */
}

/* Buttons */
.confirmDeleteButton, .cancelDeleteButton {
    padding: 10px 20px; /* Padding for buttons */
    border: none; /* Remove default border */
    border-radius: 5px; /* Rounded corners */
    cursor: pointer; /* Pointer cursor on hover */
    transition: background-color 0.3s; /* Transition for background color */
}

.confirmDeleteButton {
    background-color: #28a745; /* Green background for confirm */
    color: white; /* White text */
}

.confirmDeleteButton:hover {
    background-color: #218838; /* Darker green on hover */
}

.cancelDeleteButton {
    background-color: #dc3545; /* Red background for cancel */
    color: white; /* White text */
}

.cancelDeleteButton:hover {
    background-color: #c82333; /* Darker red on hover */
}

.deletePopup button i{
    font-size: 1rem;
}
    </style>
</head>
<body>
    <header class="admin-header">
        <div class="logo">
           <a href="provider_dashboard.php" alt="logo"><i class="fas fa-campground"></i>GoTripZ</a>
        </div>
        <div class="admin-info">
            <span class="admin-name">Welcome, <?php echo $_SESSION['admin_username']; ?></span> <!-- Display admin name -->
            <a href="admin_logout.php" class="logout"><i class="fas fa-sign-out-alt"></i> Logout</a> <!-- Logout link -->
        </div>
    </header>

    <div class="sidebar">
        <h2>Admin Menu</h2>
        <a href="admin_dashboard.php" class="menu-item">
            <i class="fas fa-tachometer-alt"></i> Dashboard
        </a>
        <a href="manage_users.php" class="menu-item">
            <i class="fas fa-user-friends"></i> All Customers
        </a>
        <div class="menu-item" onclick="toggleSubmenu('addSubmenu')">
        <i class="fas fa-plus-circle"></i> General <i class="fas fa-chevron-down chevron"></i>
        </div>
        <div class="submenu" id="addSubmenu">
            <a href="add_packages.php" class="submenu-item"><i class="fas fa-box-open"></i> Add Packages</a>
            <a href="add_itinerary.php" class="submenu-item"><i class="fas fa-map-signs"></i> Add Itinerary</a>
            
            <a href="manage_packages.php" class="submenu-item"><i class="fas fa-eye"></i> View Packages</a>
            
        </div>
        <a href="manage_bookings.php" class="menu-item">
            <i class="fas fa-calendar-check"></i> Bookings
        </a>
        
        <a href="manage_feedback.php" class="menu-item">
            <i class="fas fa-comment-dots"></i> View Feedback
        </a>
        
         <a href="manage_payments.php" class="menu-item">
            <i class="fas fa-comment-dots"></i> View Payment
        </a>

        <a href="admin_logout.php" class="menu-item">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>

    </div>

    <script>
    function toggleSubmenu(submenuId) {
        // Get all submenus
        const allSubmenus = document.querySelectorAll('.submenu');
        
        // Hide all submenus
        allSubmenus.forEach(submenu => {
            if (submenu.id !== submenuId) {
                submenu.style.maxHeight = null; // Reset max-height to hide
            }
        });

        // Toggle the clicked submenu
        const submenu = document.getElementById(submenuId);
        if (submenu.style.maxHeight) {
            submenu.style.maxHeight = null; // Hide submenu if it's already open
        } else {
            submenu.style.maxHeight = submenu.scrollHeight + "px"; // Show submenu
        }
    }
    </script>
</body>
</html>