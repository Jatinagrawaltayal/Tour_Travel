<?php
include "includes/admin_header.php"; // Include your header or session management

// Check if a delete request has been made
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    
    // Prepare and execute the delete statement
    $stmt = $conn->prepare("DELETE FROM transports WHERE transport_id = ?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    $stmt->close();

    echo "<script>alert('Transport deleted successfully!'); window.location.href = 'manage_transports.php';</script>";
}

// Fetch all transports
$query = "SELECT transport_id, transport_name FROM transports";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Transport</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            display: flex;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        h1 {
            text-align: center;
            color: #000;
            margin-bottom: 20px;
        }

        .container {
            max-width: 1200px;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            animation: fadeIn 1s ease-in-out;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #000;
            color: white;
        }

        tr {
            color: crimson;
            font-weight: bold;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        .delete-btn {
            background-color: crimson;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 5px;
        }

        .delete-btn:hover {
            background-color: darkred;
        }
    </style>
</head>
<body>

<div class="container content" id="contentArea">
    <h1>All Transport</h1>
    <table>
        <thead>
            <tr>
                <th>S/N</th>
                <th>Transport Name</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php 
                    $serialNumber = 1;
                    while ($row = $result->fetch_assoc()): 
                ?>
                    <tr>
                        <td><?php echo $serialNumber++; ?></td>
                        <td><?php echo htmlspecialchars($row['transport_name']); ?></td>
                        <td>
                            <a href="?delete_id=<?php echo $row['transport_id']; ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this transport?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="3" style="text-align: center;">No transport available.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php
    include "includes/admin_footer.php";
?>
</body>
</html>