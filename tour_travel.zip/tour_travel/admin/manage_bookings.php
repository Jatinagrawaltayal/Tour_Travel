<?php
include "includes/admin_header.php"; // Include your header or session management

// Fetch all bookings
$query = "SELECT b.book_id, b.location, b.departure_date, b.total_amount, u.username, b.booking_date 
          FROM bookings b 
          JOIN users u ON b.user_id = u.user_id"; // Join with users to get user details
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Bookings</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            display: flex;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        h1 {
            text-align: center;
            color: #000;
            margin-bottom: 20px;
        }

        .container {
            max-width: 1200px;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            animation: fadeIn 1s ease-in-out;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #000;
            color: white;
        }

        tr {
            color: crimson;
            font-weight: bold;
        }

        .action-buttons {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .view-more-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            background-color: #3498db;
            color: white;
            transition: background-color 0.3s ease;
        }

        .view-more-btn:hover {
            background-color: #2980b9;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        /* Modal styles */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1000; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgba(0, 0, 0, 0.7); /* Dark background with opacity */
    backdrop-filter: blur(5px); /* Blur effect for the background */
    transition: opacity 0.3s ease; /* Smooth transition for modal */
    color: #000
}

.modal-content {
    background-color: #fff; /* White background for the modal */
    margin: 10% auto; /* Center the modal */
    padding: 20px;
    border-radius: 10px; /* Rounded corners */
    width: 80%; /* Could be more or less, depending on screen size */
    max-width: 600px; /* Max width for larger screens */
    max-height: 80vh; /* Maximum height of the modal */
    overflow-y: auto; /* Enable vertical scrolling if content exceeds max height */
    box-shadow: 0 4px 30px rgba(0, 0, 0, 0.2); /* Shadow for depth */
    animation: slideIn 0.5s; /* Animation for modal appearance */
}

@keyframes slideIn {
    from {
        transform: translateY(-50px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

.close {
    color: #aaa; /* Light gray color */
    float: right; /* Align to the right */
    font-size: 28px; /* Font size for close button */
    font-weight: bold; /* Bold text */
    transition: color 0.3s; /* Smooth transition for hover */
}

.close:hover,
.close:focus {
    color: #e74c3c; /* Change color on hover */
    text-decoration: none; /* No underline */
    cursor: pointer; /* Pointer cursor */
}

.modal-header {
    display: flex; /* Flexbox for header */
    justify-content: space-between; /* Space between items */
    align-items: center; /* Center items vertically */
    border-bottom: 1px solid #eee; /* Bottom border */
    padding-bottom: 10px; /* Space below header */
}

.modal-title {
    font-size: 1.5rem; /* Title font size */
    color: #3498db; /* Main color */
}

.modal-body {
    margin-top: 10px; /* Space above body */
}

/* Table styles */
table {
    width: 100%; /* Full width */
    border-collapse: collapse; /* Collapse borders */
    margin-top: 10px; /* Space above the table */
}

th, td {
    border: 1px solid #ddd; /* Light gray border */
    padding: 12px; /* Padding inside cells */
    text-align: left; /* Align text to the left */
}
#modalContent td{
    color: #000;
}

th {
    background-color: #3498db; /* Header background color */
    color: white; /* Header text color */
    font-weight: bold; /* Bold text for headers */
}

tr:nth-child(even) {
    background-color: #f2f2f2; /* Light gray background for even rows */
}

tr:hover {
    background-color: #e0e0e0; /* Darker gray on hover */
    transition: background-color 0.3s; /* Smooth transition for hover */
}

tr td:nth-child(odd){
    font-weight: bold;
}

.modal-body p {
    margin: 0; /* Remove default margin for paragraphs */
    padding: 10px 0; /* Space above and below paragraphs */
}
    </style>
</head>
<body>

<div class="container content" id="contentArea">
    <h1>All Bookings</h1>
    <table>
        <thead>
            <tr>
                <th>S/N</th>
                <th>Booking ID</th>
                <th>Username</th>
                <th>Book Date</th>
                <th>Location</th>
                <th>Departure Date</th>
                <th>Total Amount</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php 
                    $serialNumber = 1;
                    while ($row = $result->fetch_assoc()): 
                ?>
                    <tr>
                        <td><?php echo $serialNumber++; ?></td>
                        <td><?php echo htmlspecialchars($row['book_id']); ?></td>
                        <td><?php echo htmlspecialchars($row['username']); ?></td>
                        <td><?php echo htmlspecialchars($row['booking_date']); ?></td>
                        <td><?php echo htmlspecialchars($row['location']); ?></td>
                        <td><?php echo htmlspecialchars($row['departure_date']); ?></td>
                        <td><?php echo htmlspecialchars($row['total_amount']); ?></td>
                        <td>
                            <a href="?booking_id=<?php echo htmlspecialchars($row['book_id']); ?>" class="view-more-btn">View More</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8" style="text-align: center;">No bookings to manage.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Modal for Booking Details -->
<div id="bookingModal" class="modal" style="display: <?php echo isset($_GET['booking_id']) ? 'block' : 'none'; ?>;">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <div id="modalContent">
            <?php
            // Fetch booking details if booking_id is provided
            if (isset($_GET['booking_id'])) {
                $booking_id = intval($_GET['booking_id']);
                $booking_stmt = $conn->prepare("SELECT * FROM bookings WHERE book_id = ?");
                $booking_stmt->bind_param("i", $booking_id);
                $booking_stmt->execute();
                $booking_details_result = $booking_stmt->get_result();

                if ($booking_details_result->num_rows > 0) {
                    $bookingDetails = $booking_details_result->fetch_assoc();
                    ?>
                    <h2>Booking Details</h2>
                    <table style="width: 100%; border-collapse: collapse;">
                        <tr>
                            <th style="border: 1px solid #ccc; padding: 10px;">Field</th>
                            <th style="border: 1px solid #ccc; padding: 10px;">Information</th>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Booking ID</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['book_id']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Name</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['name']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Email</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['email']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Phone</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['phone']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Address</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['address']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Location</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['location']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Adults</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['num_adults']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Children</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['num_children']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Departure Date</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['departure_date']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Total Amount</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['total_amount']); ?></td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 10px;">Booking Date</td>
                            <td style="border: 1px solid #ccc; padding: 10px;"><?php echo htmlspecialchars($bookingDetails['booking_date']); ?></td>
                        </tr>
                    </table>
                    <?php
                } else {
                    echo "<p>No booking details available.</p>";
                }
                $booking_stmt->close();
            }
            ?>
        </div>
    </div>
</div>

<script>
    function closeModal() {
        const modal = document.getElementById("bookingModal");
        modal.style.display = "none";
        // Optionally, you can remove the booking_id from the URL
        history.pushState({}, document.title, window.location.pathname);
    }
</script>

<?php
    include "includes/admin_footer.php";
?>
</body>
</html>