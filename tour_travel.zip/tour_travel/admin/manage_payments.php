
<?php
include "includes/admin_header.php";

// Fetch payments data
$query = "SELECT payment_id, name, email, package_name, amount, payment_date 
          FROM payments 
          ORDER BY payment_id DESC";

$result = $conn->query($query);

// Error handling
if (!$result) {
    die("SQL Error: " . $conn->error);
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Manage Payments</title>

<style>

body{
display:flex;
margin:0;
font-family:Arial, sans-serif;
}

.container{
max-width:1200px;
margin:20px;
padding:20px;
background:white;
border-radius:10px;
box-shadow:0 0 10px rgba(0,0,0,0.1);
width:100%;
}

h1{
text-align:center;
margin-bottom:20px;
}

table{
width:100%;
border-collapse:collapse;
}

th, td{
padding:12px;
border-bottom:1px solid #ddd;
text-align:left;
}

th{
background:black;
color:white;
}

tr{
color:crimson;
font-weight:bold;
}
/* Reset */
*{
margin:0;
padding:0;
box-sizing:border-box;
font-family: Arial, sans-serif;
}

/* Body */
body{
background: linear-gradient(to right, #ff758c, #ff7eb3);
}

/* Container */
.container{
max-width:1000px;
margin:80px auto;
padding:25px;
background:white;
border-radius:12px;
box-shadow:0 5px 15px rgba(0,0,0,0.2);
animation: fadeIn 0.8s ease-in-out;
}

/* Heading */
h1{
text-align:center;
margin-bottom:25px;
color:#333;
font-size:28px;
}

/* Table */
table{
width:100%;
border-collapse:collapse;
overflow:hidden;
border-radius:10px;
}

/* Table Header */
th{
background:black;
color:white;
padding:14px;
text-align:center;
font-size:15px;
}

/* Table Data */
td{
padding:12px;
text-align:center;
border-bottom:1px solid #ddd;
font-size:14px;
}

/* Row Style */
tr{
color:crimson;
font-weight:bold;
transition:0.3s;
}

/* Hover Effect */
tr:hover{
background:#f2f2f2;
transform:scale(1.01);
}

/* Empty Row */
td[colspan]{
text-align:center;
color:#555;
font-weight:normal;
}

/* Animation */
@keyframes fadeIn{
from{
opacity:0;
transform:translateY(20px);
}
to{
opacity:1;
transform:translateY(0);
}
}

/* Responsive */
@media(max-width:768px){
.container{
margin:20px;
padding:15px;
}

th, td{
font-size:12px;
padding:8px;
}
}
</style>


</head>

<body>

<div class="container">

<h1>All Payments</h1>

<table>

<thead>
<tr>
<th>S/N</th>
<th>Payment ID</th>
<th>Name</th>
<th>Email</th>
<th>Package</th>
<th>Amount (₹)</th>
<th>Date</th>
</tr>
</thead>

<tbody>

<?php if ($result->num_rows > 0): ?>

<?php
$sn = 1;
while($row = $result->fetch_assoc()):
?>

<tr>

<td><?php echo $sn++; ?></td>

<td><?php echo htmlspecialchars($row['payment_id']); ?></td>

<td><?php echo htmlspecialchars($row['name']); ?></td>

<td><?php echo htmlspecialchars($row['email']); ?></td>

<td><?php echo htmlspecialchars($row['package_name']); ?></td>

<td>₹<?php echo htmlspecialchars($row['amount']); ?></td>

<td><?php echo htmlspecialchars($row['payment_date']); ?></td>

</tr>

<?php endwhile; ?>

<?php else: ?>

<tr>
<td colspan="7" style="text-align:center;">No Payments Found</td>
</tr>

<?php endif; ?>

</tbody>

</table>

</div>

<?php include "includes/admin_footer.php"; ?>

</body>
</html>

