
<?php
include "includes/admin_header.php";

// Fetch feedbacks
$query = "SELECT feedback_id, user_id, message FROM feedbacks ORDER BY feedback_id DESC";
$result = $conn->query($query);

if(!$result){
    die("SQL Error: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Manage Feedback</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<style>

body{
display:flex;
margin:0;
padding:0;
font-family:Arial;
}

h1{
text-align:center;
color:#000;
margin-bottom:20px;
}

.container{
max-width:1200px;
padding:20px;
background:white;
border-radius:8px;
box-shadow:0 0 10px rgba(0,0,0,0.1);
}

table{
width:100%;
border-collapse:collapse;
margin-bottom:20px;
animation:fadeIn 1s ease-in-out;
}

th,td{
padding:12px;
text-align:left;
border-bottom:1px solid #ddd;
}

th{
background:black;
color:white;
}

tr{
color:crimson;
font-weight:bold;
}

@keyframes fadeIn{
from{opacity:0;}
to{opacity:1;}
}

</style>

</head>

<body>

<div class="container content" id="contentArea">

<h1>All Feedback</h1>

<table>

<thead>
<tr>
<th>S/N</th>
<th>Feedback ID</th>
<th>User ID</th>
<th>Message</th>
</tr>
</thead>

<tbody>

<?php if ($result->num_rows > 0): ?>

<?php
$serialNumber = 1;
while ($row = $result->fetch_assoc()):
?>

<tr>

<td><?php echo $serialNumber++; ?></td>

<td><?php echo htmlspecialchars($row['feedback_id']); ?></td>

<td><?php echo htmlspecialchars($row['user_id']); ?></td>

<td><?php echo htmlspecialchars($row['message']); ?></td>

</tr>

<?php endwhile; ?>

<?php else: ?>

<tr>
<td colspan="4" style="text-align:center;">No feedback available</td>
</tr>

<?php endif; ?>

</tbody>

</table>

</div>

<?php include "includes/admin_footer.php"; ?>

</body>
</html>

