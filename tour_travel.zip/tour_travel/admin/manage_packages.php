<?php
include "includes/admin_header.php"; // Include your header or session management

// Fetch all packages from the database
$query = "SELECT * FROM packages";
$stmt = $conn->prepare($query);
$stmt->execute();
$packagesResult = $stmt->get_result();
$stmt->close();

// Fetch all packages from the database along with their itinerary count
$query = "
    SELECT p.*, COUNT(i.day_number) AS itinerary_count 
    FROM packages p 
    LEFT JOIN itineraries i ON p.package_id = i.package_id 
    GROUP BY p.package_id";
$stmt = $conn->prepare($query);
$stmt->execute();
$packagesResult = $stmt->get_result();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Packages</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        h1 {
            text-align: center;
            color: #333;
            margin: 20px 0;
        }

        .container {
            max-width: 1200px;
            padding: 20px;
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* 3 cards in a row */
            gap: 20px; /* Space between cards */
            margin-left: 17rem; /* Left margin for the container */
        }

        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }

        .card h3 {
            color: crimson;
            margin-bottom: 10px;
            text-align: center;
        }

        .card img {
            width: 100%;
            height: 200px;
            border-radius: 5px;
        }

        .card p {
            color: #666;
            margin: 10px 0;
        }

        .action-buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
        }

        .edit-button, .delete-button {
            background-color: #3498db; /* Edit button color */
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .edit-button:hover {
            background-color: #2980b9; /* Darker shade on hover */
        }

        .delete-button {
            background-color: #dc3545; /* Delete button color */
        }

        .delete-button:hover {
            background-color: #c82333; /* Darker shade on hover */
        }
    </style>
</head>
<body>

<h1>Manage Packages</h1>
<div class="container">
    <?php if ($packagesResult->num_rows > 0): ?>
        <?php while ($row = $packagesResult->fetch_assoc()): ?>
            <div class="card">
                <h3><?php echo htmlspecialchars($row['package_name']); ?></h3>
                <img src="<?php echo htmlspecialchars($row['image']); ?>" alt="<?php echo htmlspecialchars($row['package_name']); ?>">
                <p><strong>Price (Infant):</strong> ₹<?php echo htmlspecialchars($row['price_infant']); ?></p>
                <p><strong>Price (Adult):</strong> ₹<?php echo htmlspecialchars($row['price_adult']); ?></p>
                <p><strong>Duration:</strong> <?php echo htmlspecialchars($row['duration']); ?> days</p>
                <div class="action-buttons">
                <a href="edit_package.php?id=<?php echo $row['package_id']; ?>" class="edit-button"><i class="fas fa-edit"></i> Edit Package</a>
                    <?php if ($row['itinerary_count'] > 0): ?>
                         <a href="edit_itinerary.php?id=<?php echo $row['package_id']; ?>" class="edit-button"><i class="fas fa-edit"></i> Edit Itinerary</a>
                    <?php endif; ?>
                    <form action="delete_package.php" method="POST" onsubmit="return confirm('Are you sure you want to delete this package?');">
                        <input type="hidden" name="id" value="<?php echo $row['package_id']; ?>">
                        <button type="submit" class="delete-button"><i class="fas fa-trash"></i>  </button>
                    </form>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p style="text-align: center;">No packages available.</p>
    <?php endif; ?>
</div>

<?php
include "includes/admin_footer.php";
?>
</body>
</html>