<?php
include "includes/admin_header.php"; // Include your header or session management

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $package_id = $_POST['package_id'];

    // Loop through the itinerary inputs
    foreach ($_POST as $key => $value) {
        if (strpos($key, 'itinerary_day_') === 0) {
            $day_number = str_replace('itinerary_day_', '', $key);
            $itinerary_content = trim($value);

            // Only insert if the itinerary content is not empty
            if (!empty($itinerary_content)) {
                // Check if the itinerary for this day already exists
                $check_stmt = $conn->prepare("SELECT COUNT(*) FROM itineraries WHERE package_id = ? AND day_number = ?");
                $check_stmt->bind_param("ii", $package_id, $day_number);
                $check_stmt->execute();
                $check_stmt->bind_result($count);
                $check_stmt->fetch();
                $check_stmt->close();

                if ($count > 0) {
                    echo "<script>alert('Itinerary for Day $day_number already exists for this package.');</script>";
                } else {
                    // Insert into the itineraries table
                    $stmt = $conn->prepare("INSERT INTO itineraries (package_id, day_number, description) VALUES (?, ?, ?)");
                    $stmt->bind_param("iis", $package_id, $day_number, $itinerary_content);
                    $stmt->execute();
                    $stmt->close();
                }
            }
        }
    }

    echo "<script>alert('Itinerary added successfully!'); window.location.href = 'add_itinerary.php';</script>";
}

// Fetch all packages for selection
$packages_query = "
    SELECT p.package_id, p.package_name, p.duration 
    FROM packages p 
    LEFT JOIN itineraries i ON p.package_id = i.package_id 
    GROUP BY p.package_id 
    HAVING COUNT(i.day_number) < p.duration"; // Only select packages without full itineraries

$packages_result = $conn->query($packages_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Itinerary</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Basic styles for the layout */
        body {
            display: flex;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        
        .container {
            max-width: 600px;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .container:hover {
            transform: scale(1.02);
        }
        h2 {
            text-align: center;
            color: #000;
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-top: 10px;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        select {
            margin: 5px 0 10px 0;
            padding: 10px;
            background: #f8f9fa;
            border: 1px solid #ced4da;
            border-radius: 5px;
            width: calc(100% - 22px);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            appearance: none; /* Remove default arrow */
            /* background-image: url('data:image/svg+xml;charset=UTF-8,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="%23333" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"%3E%3Cpolyline points="6 9 12 15 18 9"/%3E%3C/svg%3E'); */
            background-repeat: no -repeat;
            background-position: right 10px center;
            background-size: 12px;
        }
        input[type="text"], textarea {
            margin: 5px 0 10px 0;
            padding: 10px;
            background: #f8f9fa;
            border: 1px solid #ced4da;
            border-radius: 5px;
            width: calc(100% - 22px);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        input[type="text"]:focus, textarea:focus, select:focus {
            border-color: #007bff;
            outline: none;
        }
        .edit-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background: crimson;
            color: white;
            font-weight: 600;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s ease-in-out;
            cursor: pointer;
        }
        .edit-button:hover {
            background: black;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>

<div class="container content" id="contentArea">
    <h2>Add Itinerary</h2>
    <form id="itineraryForm" method="POST" action="">
        <label for="package">Select Package:</label>
        <select id="package" name="package_id" required>
            <option value="">Select a package</option>
            <?php while ($row = $packages_result->fetch_assoc()): ?>
                <option value="<?php echo $row['package_id']; ?>" data-duration="<?php echo $row['duration']; ?>">
                    <?php echo htmlspecialchars($row['package_name']); ?> (<?php echo $row['duration']; ?> days)
                </option>
            <?php endwhile; ?>
        </select>

        <div id="itineraryInputs"></div>

        <button type="submit" class="edit-button">Submit Itinerary</button>
    </form>
</div>

<script>
    document.getElementById('package').addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        const packageId = selectedOption.value;
        const duration = selectedOption.getAttribute('data-duration');
        const itineraryInputs = document.getElementById('itineraryInputs');

        // Clear previous inputs
        itineraryInputs.innerHTML = '';

        // Fetch existing itinerary days for the selected package
        fetch(`get_itinerary_days.php?package_id=${packageId}`)
            .then(response => response.json())
            .then(data => {
                const existingDays = data.existing_days;
                const remainingDays = duration - existingDays;

                // Create input fields for remaining days
                for (let i = existingDays + 1; i <= duration; i++) {
                    const input = document.createElement('textarea');
                    input.name = 'itinerary_day_' + i;
                    input.placeholder = 'Itinerary for Day ' + i;
                    itineraryInputs.appendChild(input);
                }
            });
    });
</script>

<?php
include "includes/admin_footer.php"; // Include your footer
?>
</body>
</html>