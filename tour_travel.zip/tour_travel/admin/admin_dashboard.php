<?php
include "includes/admin_header.php";

// Fetch counts
$query = "
SELECT 
(SELECT COUNT(*) FROM users) AS users,
(SELECT COUNT(*) FROM bookings) AS bookings,
(SELECT COUNT(*) FROM payments) AS payments
";

$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
?>

<div class="content">

<div class="dashboard-box">

<h2>Dashboard Overview</h2>

<div class="card-container">

<!-- Users -->
<div class="card">
    <i class="fas fa-users"></i>
    <h3>Users</h3>
    <p><?php echo $row['users']; ?></p>
</div>

<!-- Bookings -->
<div class="card">
    <i class="fas fa-calendar-check"></i>
    <h3>Bookings</h3>
    <p><?php echo $row['bookings']; ?></p>
</div>

<!-- Payments -->
<div class="card">
    <i class="fas fa-credit-card"></i>
    <h3>Payments</h3>
    <p><?php echo $row['payments']; ?></p>
</div>

</div>

</div>

</div>

<style>

/* REMOVE BODY FLEX ISSUE */
body{
margin:0;
font-family:Arial, sans-serif;
}

/* Main Box */
.dashboard-box{
background:white;
padding:30px;
border-radius:10px;
max-width:1000px;
margin:auto;
box-shadow:0 0 10px rgba(0,0,0,0.1);
}

/* Heading */
.dashboard-box h2{
text-align:center;
margin-bottom:30px;
color:#333;
}

/* Card Layout */
.card-container{
display:flex;
justify-content:center;
gap:20px;
flex-wrap:wrap;
}

/* Card */
.card{
background:#f8f9fa;
padding:25px;
border-radius:12px;
width:220px;
text-align:center;
box-shadow:0 4px 10px rgba(0,0,0,0.1);
transition:0.3s;
}

/* Hover */
.card:hover{
transform:translateY(-8px);
box-shadow:0 8px 20px rgba(0,0,0,0.2);
}

/* Icon */
.card i{
font-size:35px;
color:crimson;
margin-bottom:10px;
}

/* Title */
.card h3{
margin-bottom:10px;
color:#333;
}

/* Number */
.card p{
font-size:28px;
font-weight:bold;
color:crimson;
}

/* Responsive */
@media(max-width:768px){
.card-container{
flex-direction:column;
align-items:center;
}
}

</style>

<?php include "includes/admin_footer.php"; ?>