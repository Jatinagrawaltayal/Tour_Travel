<?php
session_start(); // Start the session

// Check if the user is an admin
if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    // Unset all session variables for admin
    $_SESSION = array();

    // Destroy the session
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }

    // Finally, destroy the session
    session_destroy();
}

// Redirect to the login page
header("Location: admin_login.php"); // Change this to your login page
exit();
?>