<?php
include "includes/admin_header.php"; // Include your header or session management

// Check if the package ID is set in the URL
if (isset($_GET['id'])) {
    $package_id = $_GET['id'];

    // Fetch package details from the database
    $stmt = $conn->prepare("SELECT * FROM packages WHERE package_id = ?");
    $stmt->bind_param("i", $package_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $package = $result->fetch_assoc();
    } else {
        echo "<script>alert('Package not found.'); window.location.href='manage_packages.php';</script>";
        exit();
    }

    // Fetch existing itinerary details for the package
    $itinerary_stmt = $conn->prepare("SELECT day_number, description FROM itineraries WHERE package_id = ? ORDER BY day_number");
    $itinerary_stmt->bind_param("i", $package_id);
    $itinerary_stmt->execute();
    $itinerary_result = $itinerary_stmt->get_result();
} else {
    echo "<script>alert('Invalid package ID.'); window.location.href='manage_packages.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Itinerary for <?php echo htmlspecialchars($package['package_name']); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Basic styles for the layout */
        body {
            display: flex;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        
        .container {
            max-width: 600px;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .container:hover {
            transform: scale(1.02);
        }
        h2 {
            text-align: center;
            color: #000;
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-top: 10px;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        select {
            margin: 5px 0 10px 0;
            padding: 10px;
            background: #f8f9fa;
            border: 1px solid #ced4da;
            border-radius: 5px;
            width: calc(100% - 22px);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        input[type="text"], textarea {
            margin: 5px 0 10px 0;
            padding: 10px;
            background: #f8f9fa;
            border: 1px solid #ced4da;
            border-radius: 5px;
            width: calc(100% - 22px);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        input[type="text"]:focus, textarea:focus, select:focus {
            border-color: #007bff;
            outline: none;
        }
        .edit-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background: crimson;
            color: white;
            font-weight: 600;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s ease-in-out;
            cursor: pointer;
        }
        .edit-button:hover {
            background: black;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>

<div class="container content" id="contentArea">
    <h2>Edit Itinerary for <?php echo htmlspecialchars($package['package_name']); ?></h2>
    <form id="itineraryForm" method="POST" action="">
        <input type ="hidden" name="package_id" value="<?php echo $package_id; ?>">
        
        <?php while ($itinerary_row = $itinerary_result->fetch_assoc()): ?>
            <label for="itinerary_day_<?php echo $itinerary_row['day_number']; ?>">Itinerary for Day <?php echo $itinerary_row['day_number']; ?>:</label>
            <textarea id="itinerary_day_<?php echo $itinerary_row['day_number']; ?>" name="itinerary_day_<?php echo $itinerary_row['day_number']; ?>" required><?php echo htmlspecialchars($itinerary_row['description']); ?></textarea>
        <?php endwhile; ?>

        <button type="submit" class="edit-button">Update Itinerary</button>
    </form>
</div>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ensure the package ID is still valid
    if (isset($_POST['package_id'])) {
        $package_id = $_POST['package_id'];

        // Update the itinerary in the database
        foreach ($_POST as $key => $value) {
            if (strpos($key, 'itinerary_day_') === 0) {
                $day_number = str_replace('itinerary_day_', '', $key);
                $itinerary_content = trim($value);

                // Update the itinerary for this day
                $update_stmt = $conn->prepare("UPDATE itineraries SET description = ? WHERE package_id = ? AND day_number = ?");
                $update_stmt->bind_param("sii", $itinerary_content, $package_id, $day_number);
                $update_stmt->execute();
                $update_stmt->close();
            }
        }

        echo "<script>alert('Itinerary updated successfully!'); window.location.href = 'manage_packages.php';</script>";
    } else {
        echo "<script>alert('Invalid package ID.'); window.location.href='manage_packages.php';</script>";
        exit();
    }
}
?>

<?php
include "includes/admin_footer.php"; // Include your footer
?>
</body>
</html>