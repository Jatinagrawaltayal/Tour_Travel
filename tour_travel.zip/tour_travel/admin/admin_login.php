<?php
include '../database/conn.php';  

$error_message = ""; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query to check admin credentials
    $query = "SELECT * FROM admins WHERE username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $admin = $result->fetch_assoc();

        // Directly compare the password (not recommended)
        if ($password === $admin['password']) {
            // Set session variables
            $_SESSION['user_id'] = $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            $_SESSION['role'] = 'admin'; // Store the role in session

            // Redirect to admin dashboard
            header("Location: admin_dashboard.php");
            exit();
        } else {
            $error_message = "Invalid credentials."; // Set error message
        }
    } else {
        $error_message = "Invalid credentials."; // Set error message
    }

    // Redirect to the same page to avoid resubmission
    header("Location: " . $_SERVER['PHP_SELF'] . "?error=" . urlencode($error_message));
    exit();
}

// Check for error message in the URL
if (isset($_GET['error'])) {
    $error_message = urldecode($_GET['error']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        <?php
        include 'assets/css/admin_login.css';
        ?>
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Admin Login</h2>
        <form method="POST" action="">
            <label for="username">Username:</label>
            <input type="text" name="username" required>
            <label for="password">Password:</label>
            <div class="input-container">
                <input type="password" name="password" id="password" required>
                <i class="fas fa-eye-slash toggle-password" id="togglePassword" onclick="togglePasswordVisibility()"></i>
            </div>
            <button type="submit">Login</button>
        </form>
    </div>

    <!-- Error Modal -->
    <div id="errorModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <p id="errorText"></p>
        </div>
    </div>

    <script>
        function togglePasswordVisibility() {
            const passwordInput = document.getElementById('password');
            const toggleIcon = document.getElementById('togglePassword');
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            }
        }

        // Show the modal with the error message
        function showErrorModal(message) {
            document.getElementById('errorText').innerText = message;
            document.getElementById('errorModal').style.display = 'block';
        }

        // Close the modal
        function closeModal() {
            document.getElementById('errorModal').style.display = 'none';
        }

        // Check if there's an error message and show the modal
        window.onload = function() {
            <?php if (!empty($error_message)) { ?>
                showErrorModal("<?php echo $error_message; ?>");
            <?php } ?>
        };
    </script>
</body>
</html>