<?php
include "includes/admin_header.php"; // Include your header or session management

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $package_id = $_POST['id'];

    // Delete the package from the packages table
    $stmt = $conn->prepare("DELETE FROM packages WHERE package_id = ?");
    $stmt->bind_param("i", $package_id);
    $stmt->execute();
    $stmt->close();

    // Delete the itinerary for the package from the itineraries table
    $stmt = $conn->prepare("DELETE FROM itineraries WHERE package_id = ?");
    $stmt->bind_param("i", $package_id);
    $stmt->execute();
    $stmt->close();

    echo "<script>alert('Package deleted successfully!'); window.location.href = 'manage_packages.php';</script>";
}

$conn->close(); // Close the database connection
?>