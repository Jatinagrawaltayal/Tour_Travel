<?php
include "includes/admin_header.php"; // Include your header or session management

// Check if the package ID is set in the URL
if (isset($_GET['id'])) {
    $package_id = $_GET['id'];

    // Fetch package details from the database
    $stmt = $conn->prepare("SELECT * FROM packages WHERE package_id = ?");
    $stmt->bind_param("i", $package_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $package = $result->fetch_assoc();
    } else {
        echo "<script>alert('Package not found.'); window.location.href='manage_packages.php';</script>";
        exit();
    }
} else {
    echo "<script>alert('Invalid package ID.'); window.location.href='manage_packages.php';</script>";
    exit();
}

if (isset($_POST['update_package'])) {
    // Handle form submission
    $package_name = trim($_POST['package_name']);
    $description = trim($_POST['description']);
    $price_adult = trim($_POST['price_adult']);
    $price_infant = trim($_POST['price_infant']);
    $duration = trim($_POST['duration']);
    $inclusions = trim($_POST['inclusions']);
    $exclusions = trim($_POST['exclusions']);
    $age_restrictions = trim($_POST['age_restrictions']);
    $contact_info = trim($_POST['contact_info']);
    
    // Handle image upload
    if ($_FILES['image']['name']) {
        $image = $_FILES['image']['name'];
        $target_dir = "assets/images/package_images/uploads/"; // Directory where images will be uploaded
        $target_file = $target_dir . basename($image);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if image file is a actual image or fake image
        $check = getimagesize($_FILES['image']['tmp_name']);
        if ($check === false) {
            echo "<script>alert('File is not an image.');</script>";
            $uploadOk = 0;
        }

        // Check file size (limit to 5MB)
        if ($_FILES['image']['size'] > 5000000) {
            echo "<script>alert('Sorry, your file is too large.');</script>";
            $uploadOk = 0;
        }

        // Allow certain file formats including AVIF and WEBP
        if (!in_array($imageFileType, ['jpg', 'png', 'jpeg', 'gif', 'avif', 'webp'])) {
            echo "<script>alert('Sorry, only JPG, JPEG, PNG, GIF, AVIF & WEBP files are allowed.');</script>";
            $uploadOk = 0;
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "<script>alert('Sorry, your file was not uploaded.');</script>";
        } else {
            // If everything is ok, try to upload file
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                // Update the package with the new image
                $stmt = $conn->prepare("UPDATE packages SET package_name=?, description=?, price_adult=?, price_infant=?, duration=?, image=?, inclusions=?, exclusions=?, age_restrictions=?, contact_info=? WHERE package_id=?");
                $stmt->bind_param("ssddsssssii", $package_name, $description, $price_adult, $price_infant, $duration, $target_file, $inclusions, $exclusions, $age_restrictions, $contact_info, $package_id);
                $stmt->execute();
                $stmt->close();

                // Use JavaScript to redirect after form submission
                echo "<script>
                        alert('Package updated successfully!');
                        window.location.href = 'manage_packages.php';
                      </script>";
            } else {
                echo "<script>alert('Sorry, there was an error uploading your file.');</script>";
            }
        }
    } else {
        // If no new image is uploaded, just update other details
        $stmt = $conn->prepare("UPDATE packages SET package_name=?, description=?, price_adult=?, price_infant=?, duration=?, inclusions=?, exclusions=?, age_restrictions=?, contact_info=? WHERE package_id=?");
        $stmt->bind_param("ssddsssssi", $package_name, $description, $price_adult, $price_infant, $duration, $inclusions, $exclusions, $age_restrictions, $contact_info, $package_id);
        $stmt->execute();
        $stmt->close();

        // Use JavaScript to redirect after form submission
        echo "<script>
                alert('Package updated successfully!');
                window.location.href = 'manage_packages.php';
              </script>";
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Package</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Basic styles for the layout */
        body {
            display: flex;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        
        .container {
            max-width: 600px;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .container:hover {
            transform: scale(1.02);
        }
        h2 {
            text-align: center;
            color: #000;
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-top: 10px;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        input[type="text"], input[type="number"], textarea {
            margin: 5px 0 10px 0;
            padding: 10px;
            background: #f8f9fa;
            border: 1px solid #ced4da;
            border-radius: 5px;
            width: calc(100% - 22px);
            box-shadow: 0  1px 3px rgba(0, 0, 0, 0.1);
        }
        input[type ="text"]:focus, input[type="number"]:focus, textarea:focus {
            border-color: #007bff;
            outline: none;
        }
        .edit-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background: crimson;
            color: white;
            font-weight: 600;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s ease-in-out;
            cursor: pointer;
        }
        .edit-button:hover {
            background: black;
            transform: translateY(-2px);
        }
        #imagePreview {
            display: block;
            margin: 10px 0;
            max-width: 100%;
            height: auto;
            border: 1px solid #ced4da;
            border-radius: 5px;
        }
        img {
            width: 100px;
        }
    </style>
    <script>
        function previewImage(event) {
            const imagePreview = document.getElementById('imagePreview');
            const file = event.target.files[0];
            const reader = new FileReader();
            reader.onload = function() {
                imagePreview.src = reader.result;
            }
            if (file) {
                reader.readAsDataURL(file);
            }
        }
    </script>
</head>
<body>

<div class="container content" id="contentArea">
    <h2>Edit Package</h2>
    <form id="packageForm" method="POST" action="" enctype="multipart/form-data">
        <label for="image">Upload Image :</label>
        <img id="imagePreview" src="<?php echo htmlspecialchars($package['image']); ?>" alt="Image Preview" />
        <input type="file" name="image" accept="image/*" onchange="previewImage(event)">

        <label for="package_name">Package Name:</label>
        <input type="text" name="package_name" value="<?php echo htmlspecialchars($package['package_name']); ?>" required>

        <label for="description">Description:</label>
        <textarea name="description" rows="4" required><?php echo htmlspecialchars($package['description']); ?></textarea>

        <label for="price_adult">Price (Adult, 13 years and above):</label>
        <input type="number" name="price_adult" step="0.01" value="<?php echo htmlspecialchars($package['price_adult']); ?>" required >

        <label for="price_infant">Price (Infant, 0-2 years):</label>
        <input type="number" name="price_infant" step="0.01" value="<?php echo htmlspecialchars($package['price_infant']); ?>" required>

        <label for="duration">Duration (days):</label>
        <input type="number" name="duration" value="<?php echo htmlspecialchars($package['duration']); ?>" required>

        <label for="inclusions">Inclusions:</label>
        <textarea name="inclusions" rows="4" required><?php echo htmlspecialchars($package['inclusions']); ?></textarea>

        <label for="exclusions">Exclusions:</label>
        <textarea name="exclusions" rows="4" required><?php echo htmlspecialchars($package['exclusions']); ?></textarea>

        <label for="age_restrictions">Age Restrictions:</label>
        <textarea name="age_restrictions" rows="4" required><?php echo htmlspecialchars($package['age_restrictions']); ?></textarea>

        <label for="contact_info">Contact Information:</label>
        <textarea name="contact_info" rows="4" required><?php echo htmlspecialchars($package['contact_info']); ?></textarea>

        <button class="edit-button" type="submit" name="update_package">Update Package</button>
    </form>
</div>

<?php
include "includes/admin_footer.php";
?>
</body>
</html>