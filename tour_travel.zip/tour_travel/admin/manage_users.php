<?php
include "includes/admin_header.php";

// Fetch providers with status 'Requested'
$query = "SELECT * FROM users";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Providers Approval</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            display: flex;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        h1 {
            text-align: center;
            color: #000;
            margin-bottom: 20px;
        }

        .container {
            max-width: 1200px;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            animation: fadeIn 1s ease-in-out;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #000;
            color: white;
        }

        tr{
            color: crimson;
            font-weight: bold;
        }

        .action-buttons {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .approve-btn, .reject-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 0 10px;
            transition: background-color 0.3s ease;
        }

        .approve-btn {
            background-color: #28a745;
            color: white;
        }

        .approve-btn:hover {
            background-color: #218838;
        }

        .reject-btn {
            background-color: #dc3545;
            color: white;
        }

        .reject-btn:hover {
            background-color: #c82333;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }
    </style>
</head>
<body>

<div class="container content" id="contentArea">
    <h1>All Customers</h1>
    <table>
        <thead>
            <tr>
                <th>S/N</th>
                <th>Username</th>
                <th>Email</th>
                <th>Registered On</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php 
                        $serialNumber = 1;
                        while ($row = $result->fetch_assoc()): 
                ?>
                    <tr>
                        <td><?php echo $serialNumber++; ?></td>
                        <td><?php echo htmlspecialchars($row['username']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8" style="text-align: center;">No customers to manage.</td>
                </tr>
            <?php endif; ?>
            </tbody>
    </table>
</div>

<script>
    function deactivateUsers(username) {
        if (confirm("Are you sure you want to deactivate this provider?")) {
            const xhr = new XMLHttpRequest();
            xhr.open("POST", "update_provider_status.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    const response = JSON.parse(xhr.responseText);
                    alert(response.message);
                    if (response.success) {
                        location.reload(); // Reload the page to see the updated status
                    }
                }
            };
            xhr.send("username=" + encodeURIComponent(username) + "&action=deactivate");
        }
    }

    function deleteUsers(username) {
        if (confirm("Are you sure you want to delete this provider?")) {
            const xhr = new XMLHttpRequest();
            xhr.open("POST", "delete_provider.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    const response = JSON.parse(xhr.responseText);
                    alert(response.message);
                    if (response.success) {
                        location.reload(); // Reload the page to see the updated list
                    }
                }
            };
            xhr.send("username=" + encodeURIComponent(username));
        }
    }
</script>


<?php
    include "includes/admin_footer.php";
?>
</body>
</html>