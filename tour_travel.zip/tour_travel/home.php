<?php
    include "includes/user_header.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>Go Trip</title>
    <style>
        /* Home Section */
        .home {
            position: relative;
            overflow: hidden; /* Hide overflow */
        }

        .home-side {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 60vh; /* Minimum height for the section */
            background-color: #3498db; /* Main color */
            color: #fff; /* White text */
            text-align: center; /* Center text */
            padding: 20px; /* Padding */
        }

        .slider {
            display: flex;
            transition: transform 0.5s ease-in-out; /* Smooth transition */
            width: 100%;
        }

        .slide {
            flex: 1 0 100%; /* Full width for each slide */
            background-size: cover; /* Cover the area */
            background-position: center; /* Center the image */
            display: flex;
            align-items: center;
            justify-content: center;
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%; /* Ensure the slide takes full height */
            opacity: 0; /* Start hidden */
            transition: opacity 0.5s ease-in-out; /* Smooth transition for opacity */
        }

        .slide.active {
            opacity: 1; /* Show the active slide */
        }

        .slide .content {
            position: absolute; /* Position content over the image */
            bottom: 20px; /* Space from the bottom */
            left: 50%; /* Center horizontally */
            transform: translateX(-50%); /* Center adjustment */
            text-align: center; /* Center text */
        }

        .slide .tagline {
            font-size: 1.5rem; /* Tagline size */
            margin-bottom: 10px; /* Space below tagline */
            color: #fff; /* White text */
        }

        .slide h3 {
            font-size: 2.5rem; /* Title size */
            margin-bottom: 20px; /* Space below title */
            color: #fff; /* White text */
        }

        .slide .btn {
            padding: 10px 20px; /* Button padding */
            background-color: #e74c3c; /* Accent color */
            color: #fff; /* White text */
            border: none; /* No border */
            border-radius: 5px; /* Rounded corners */
            text-decoration: none; /* No underline */
            transition: background-color 0.3s; /* Animation for hover */
        }

        .slide .btn:hover {
            background-color: #c0392b; /* Darker shade on hover */
        }

        /* Services Section */
        .services {
            padding: 50px 20px;
            text-align: center; /* Center text */
            background-color: #fff; /* White background */
        }

        .services h1 {
            font-size: 2.5rem; /* Title size */
            margin-bottom: 40px; /* Space below title */
            color: #333; /* Dark text */
        }

        .services .box-container {
            display: flex;
            flex-wrap: wrap; /* Allow wrapping */
            justify-content: center; /* Center items */
            gap: 20px; /* Space between boxes */
        }

        .services .box-container .box {
            background-color: #f9f9f9; /* Light background for boxes */
            border-radius: 10px; /* Rounded corners */
            padding: 20px; /* Padding inside boxes */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Subtle shadow */
            transition: transform 0.3s, box-shadow 0.3s; /* Animation for hover */
            width: 200px; /* Fixed width for boxes */
        }

        .services .box-container.box:hover {
            transform: translateY(-5px); /* Lift effect on hover */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); /* Enhanced shadow on hover */
        }

        .services .box-container .box img {
            width: 80px; /* Fixed width for images */
            height: 80px;
            border-radius: 50%; /* Rounded corners */
            border: 2px solid #3498db; /* Main color border */
            height: auto; /* Maintain aspect ratio */
            margin-bottom: 10px; /* Space below image */
        }

        /* Home About Section */
        .home-about {
            display: flex;
            align-items: center; /* Center vertically */
            padding: 50px 20px; /* Padding */
            background-color: #e9ecef; /* Light gray background */
        }

        .home-about .image {
            flex: 1; /* Take half the space */
            padding: 20px; /* Padding */
        }

        .home-about .image img {
            width: 100%; /* Full width */
            border-radius: 10px; /* Rounded corners */
        }

        .home-about .content {
            flex: 1; /* Take half the space */
            padding: 20px; /* Padding */
        }

        .home-about h3 {
            font-size: 2rem; /* Title size */
            margin-bottom: 20px; /* Space below title */
            color: #333; /* Dark text */
        }

        .home-about p {
            margin-bottom: 20px; /* Space below paragraph */
            color: #555; /* Darker gray text */
        }

        .home-about .btn {
            padding: 10px 20px; /* Button padding */
            background-color: #3498db; /* Main color */
            color: #fff; /* White text */
            border: none; /* No border */
            border-radius: 5px; /* Rounded corners */
            text-decoration: none; /* No underline */
            transition: background-color 0.3s; /* Animation for hover */
        }

        .home-about .btn:hover {
            background-color: #2980b9; /* Darker shade on hover */
        }

        /* Home Packages Section */
        .home-packages {
            padding: 50px 20px; /* Padding */
            background-color: #fff; /* White background */
        }

        .home-packages h1 {
            font-size: 2.5rem; /* Title size */
            margin-bottom: 40px; /* Space below title */
            color: #333; /* Dark text */
            text-align: center; /* Center text */
        }

        .home-packages .box-container {
            display: flex;
            flex-wrap: wrap; /* Allow wrapping */
            justify-content: center; /* Center items */
            gap: 20px; /* Space between boxes */
        }

        .home-packages .box {
            background-color: #f9f9f9; /* Light background for boxes */
            border-radius: 10px; /* Rounded corners */
            overflow: hidden; /* Hide overflow */
            width: 300px; /* Fixed width for boxes */
            transition: transform 0.3s, box-shadow 0.3s; /* Animation for hover */
        }

        .home-packages .box:hover {
            transform: translateY(-5px); /* Lift effect on hover */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); /* Enhanced shadow on hover */
        }

        .home-packages .box .image img {
            width: 100%; /* Full width */
            height: auto; /* Maintain aspect ratio */
        }

        .home-packages .box .content {
            padding: 20px; /* Padding inside boxes */
            text-align: center; /* Center text */
        }

        .home-packages .box .content h3 {
            font-size: 1.5rem; /* Title size */
            margin-bottom: 10px; /* Space below title */
            color: #333; /* Dark text */
        }

        .home-packages .box .content p {
            margin-bottom: 20px; /* Space below paragraph */
            color: #555; /* Darker gray text */
        }

        .home-packages .box .content .btn {
            padding: 10px 20px; /* Button padding */
            background-color: #3498db; /* Main color */
            color: #fff; /* White text */
            border: none; /* No border */
            border-radius: 5px; /* Rounded corners */
            text-decoration: none; /* No underline */
            transition: background-color 0.3s; /* Animation for hover */
        }

        .home-packages .box .content .btn:hover {
            background-color: #2980b9; /* Darker shade on hover */
        }

        /* Home Offer Section */
        .home-offer {
            display : flex;
            align-items: center; /* Center vertically */
            justify-content: center; /* Center content */
            padding: 50px 20px; /* Padding */
            background-color: #e74c3c; /* Offer background color */
            color: #fff; /* White text */
            text-align: center; /* Center text */
        }

        .home-offer h3 {
            font-size: 2rem; /* Title size */
            margin-bottom: 20px; /* Space below title */
        }

        .home-offer p {
            margin-bottom: 20px; /* Space below paragraph */
        }

        .home-offer .btn {
            padding: 10px 20px; /* Button padding */
            background-color: #fff; /* White button */
            color: #e74c3c; /* Text color */
            border: none; /* No border */
            border-radius: 5px; /* Rounded corners */
            text-decoration: none; /* No underline */
            transition: background-color 0.3s; /* Animation for hover */
        }

        .home-offer .btn:hover {
            background-color: #f1c40f; /* Highlight on hover */
        }

        .load-more {
            text-align: center; /* Center the button */
            margin-top: 40px; /* Space above the button */
        }

        .load-more a {
            text-decoration: none; /* No underline */
        }

        .load-more .btn {
            padding: 12px 30px; /* Button padding */
            font-size: 1.2rem; /* Button font size */
            background-color: #3498db; /* Main color */
            color: #fff; /* White text */
            border: none; /* No border */
            border-radius: 5px; /* Rounded corners */
            cursor: pointer; /* Pointer cursor */
            transition: background-color 0.3s, transform 0.3s; /* Animation for hover */
        }

        .load-more .btn:hover {
            background-color: #2980b9; /* Darker shade on hover */
            transform: translateY(-3px); /* Lift effect on hover */
        }
    </style>
</head>
<body>
<section class="home">
    <div class="home-side">
        <div class="slider">
            <!-- Slide 1 -->
            <div class="slide active" style="background-image: url('assets/images/banner1.webp');">
                <div class="content">
                    <span class="tagline">Explore, Discover, Travel</span>
                    <h3>Travel Around the World</h3>
                    <a href="package.php" class="btn">Discover More</a>
                </div>
            </div>
            <!-- Slide 2 -->
            <div class="slide" style="background-image: url('assets/images/banner2.avif');">
                <div class="content">
                    <span class="tagline">Explore, Discover, Travel</span>
                    <h3>Discover New Places</h3>
                    <a href="package.php" class="btn">Discover More</a>
                </div>
            </div>
            <!-- Slide 3 -->
            <div class="slide" style="background-image: url('assets/images/banner1.webp');">
                <div class="content">
                    <span class="tagline">Explore, Discover, Travel</span>
                    <h3>Make Your Tour Worthwhile</h3>
                    <a href="package.php" class="btn">Discover More</a>
                </div>
            </div>
        </div>
    </div>
</section>

    <section class="services">
        <h1 class="heading-title">Our Services</h1>
        <div class="box-container">
            <div class="box">
                <img src="assets/images/service2.png" alt="Adventure Service Icon" />
                <h3>Adventure Service</h3>
            </div>
            <div class="box">
                <img src="assets/images/service1.png" alt="Tour Guide Service Icon" />
                <h3>Tour Guide Service</h3>
            </div>
            <div class="box">
                <img src="assets/images/service3.avif" alt="Trekking" />
                <h3>Trekking</h3>
            </div>
            <div class="box">
                <img src="assets/images/service4.png" alt="Camp Fire Icon" />
                <h3>Camp Fire</h3>
            </div>
            <div class="box">
                <img src="assets/images/service5.avif" alt="Off Road Icon" />
                <h3>Off Road</h3>
            </div>
            <div class="box">
                <img src="assets/images/service6.png" alt="Camping Icon"/> <h3>Camping</h3>
            </div>
        </div>
    </section>

    <section class="home-about">
        <div class="image">
            <img src="assets/images/home_about.jpeg" alt="">
        </div>
        <div class="content">
            <h3>About Us</h3>
            <p>Travelling is an amazing way to learn a lot of things in life. A lot of people around the world travel every year to many places. Moreover, it is important to travel to humans. Some travel to learn more while some travel to take a break from their life.</p>
            <a href="About.php" class="btn">Read More</a>
        </div>
    </section>

    <section class="home-packages">
        <h1 class="heading-title">Our Packages</h1>
        <div class="box-container">
            <div class="box">
                <div class="image">
                    <img src="assets/images/package1.jpg" alt="Adventure & Tour">
                </div>
                <div class="content">
                    <h3>Adventure & Tour</h3>
                    <p>Adventure tourism is a type of travel that involves exploring new places, engaging in physical activity, and connecting with new cultures.</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>

            <div class="box">
                <div class="image">
                    <img src="assets/images/package2.jpg" alt="Beach Vacation">
                </div>
                <div class="content">
                    <h3>Beach Vacation</h3>
                    <p>Escape to a tropical paradise with white sandy beaches and crystal-clear water. Perfect for a relaxing getaway.</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>

            <div class="box">
                <div class="image">
                    <img src="assets/images/package3.jpeg" alt="Mountain Adventure">
                </div>
                <div class="content">
                    <h3>Mountain Adventure</h3>
                    <p>Explore the mountains and enjoy the breathtaking views. A perfect tour for adventure lovers.</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
        </div>

        <div class="load-more">
            <a href="package.php" class="btn">Load More</a>
        </div>
    </section>

    <section class="home-offer">
        <div class="content">
            <h3>50% Offer</h3>
            <p>Don't miss out on this exclusive deal. Act now to get the best price on our services!</p>
            <a href="book.php" class="btn">Book Now</a>
        </div>
    </section>

    <script>
// JavaScript for Slider Functionality
let currentSlideIndex = 0;
const slides = document.querySelectorAll('.slide');

function showSlide(index) {
    slides.forEach((slide, i) => {
        slide.classList.remove('active');
        if (i === index) {
            slide.classList.add('active');
        }
    });
}

function nextSlide() {
    currentSlideIndex = (currentSlideIndex + 1) % slides.length;
    showSlide(currentSlideIndex);
}

showSlide(currentSlideIndex);
setInterval(nextSlide, 5000); // Change slide every 5 seconds

// Add event listener to each slide for manual navigation
slides.forEach((slide, index) => {
    slide.addEventListener('click', () => {
        currentSlideIndex = index;
        showSlide(currentSlideIndex);
    });
});

        document.querySelector('.load-more .btn').addEventListener('click', function() {
            const hiddenBoxes = document.querySelectorAll('.home-packages .box:not(.loaded)');
            hiddenBoxes.forEach((box, index) => {
                if (index < 3) { // Show 3 boxes at a time
                    box.classList.add('loaded');
                }
            });

            // Hide "Load More" if all boxes are loaded
            if (document.querySelectorAll('.home-packages .box:not(.loaded)').length === 0) {
                this.style.display = 'none';
            }
        });
    </script>

    <?php
        include "includes/user_footer.php";
    ?>
</body>
</html>