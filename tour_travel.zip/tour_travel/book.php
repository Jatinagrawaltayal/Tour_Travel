<?php
include "includes/user_header.php";

if (!isset($_SESSION['user_id'])) {
    echo "<script>window.location.href='user_login_register.php';</script>";
    exit();
}

// ✅ FIX: float conversion
$package_name = isset($_GET['name']) ? htmlspecialchars($_GET['name']) : '';
$price_adult = isset($_GET['price_adult']) ? (float)$_GET['price_adult'] : 0;
$price_infant = isset($_GET['price_infant']) ? (float)$_GET['price_infant'] : 0;

// transport
$transport_query = "SELECT transport_id, transport_name FROM transports";
$transport_result = $conn->query($transport_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Go Trip</title>

<style>
.booking {
    padding: 50px 20px;
    max-width: 800px;
    margin: 0 auto;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    margin-top: 1rem;
    margin-bottom: 1rem;
}

.booking h1 {
    text-align: center;
    font-size: 2.5rem;
    margin-bottom: 30px;
    color: #333;
}

.book-form {
    display: flex;
    flex-direction: column;
}

.flex {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
}

.inputbox {
    flex: 1 1 calc(50% - 20px);
    display: flex;
    flex-direction: column;
}

.inputbox span {
    margin-bottom: 5px;
    font-weight: bold;
}

.inputbox input {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.btn {
    margin-top: 20px;
    padding: 12px;
    background-color: #3498db;
    color: #fff;
    border: none;
    border-radius: 5px;
    font-size: 1.2rem;
    cursor: pointer;
}

.btn:hover {
    background-color: #2980b9;
}

.package-details {
    margin-bottom: 20px;
    padding: 15px;
    background-color: #f9f9f9;
    border: 1px solid #ddd;
    border-radius: 5px;
}

/* 🔥 highlight total */
#totalAmount {
    background-color: #eaf6ff;
    font-weight: bold;
    color: #2c3e50;
}
</style>

</head>

<body>

<section class="booking">
<h1>Book Your Trip</h1>

<div class="package-details">
    <h3>Selected Package</h3>
    <p><b><?php echo $package_name; ?></b></p>
    <p>Adult Price: ₹<?php echo $price_adult; ?></p>
    <p>Child Price: ₹<?php echo $price_infant; ?></p>
</div>

<form action="payment.php" method="post" class="book-form">

<input type="hidden" name="package_name" value="<?php echo $package_name; ?>">
<input type="hidden" name="price_adult" value="<?php echo $price_adult; ?>">
<input type="hidden" name="price_infant" value="<?php echo $price_infant; ?>">

<div class="flex">

<div class="inputbox">
<span>Name</span>
<input type="text" name="name" required>
</div>

<div class="inputbox">
<span>Email</span>
<input type="email" name="email" required>
</div>

<div class="inputbox">
<span>Phone</span>
<input type="number" name="number" required>
</div>

<div class="inputbox">
<span>Address</span>
<input type="text" name="address" required>
</div>

<div class="inputbox">
<span>Children</span>
<input type="number" id="numChildren" name="num_children" value="0" min="0" oninput="calculateTotal()">
</div>

<div class="inputbox">
<span>Adults</span>
<input type="number" id="numAdults" name="num_adults" value="1" min="1" oninput="calculateTotal()">
</div>

<div class="inputbox">
<span>Booking Date</span>
<input type="date" name="booking_date" value="<?php echo date('Y-m-d'); ?>" required>
</div>

<div class="inputbox">
<span>Departure Date</span>
<input type="date" name="departure_date" required>
</div>

<div class="inputbox">
<span>Total Amount</span>
<input type="text" id="totalAmount" name="total_amount" readonly>
</div>

</div>

<input type="submit" value="Proceed to Payment" class="btn">

</form>
</section>

<script>
function calculateTotal() {

    var adults = parseInt(document.getElementById("numAdults").value) || 0;
    var children = parseInt(document.getElementById("numChildren").value) || 0;

    var priceAdult = <?php echo $price_adult; ?>;
    var priceChild = <?php echo $price_infant; ?>;

    var total = (adults * priceAdult) + (children * priceChild);

    document.getElementById("totalAmount").value = total.toFixed(2);
}

// ✅ AUTO CALCULATE ON LOAD
window.onload = function() {
    calculateTotal();
};
</script>

<?php include "includes/user_footer.php"; ?>
</body>
</html>