<?php
include "database/conn.php";

// ✅ Safe session start
if(session_status() === PHP_SESSION_NONE){
    session_start();
}

// ✅ Get data safely
$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$package_name = $_POST['package_name'] ?? '';
$amount = $_POST['amount'] ?? 0;

// ✅ Remove ₹ if present
$amount = str_replace('₹', '', $amount);
$amount = trim($amount);

// ✅ Validation
if(empty($name) || empty($package_name) || empty($amount)){
    die("Invalid Booking Data");
}

// ✅ Insert into DB (ONLY valid columns)
$sql = "INSERT INTO payments (name, email, package_name, amount) 
        VALUES ('$name','$email','$package_name','$amount')";

if(mysqli_query($conn, $sql)){

    // ✅ Store session
    $_SESSION['name'] = $name;
    $_SESSION['package_name'] = $package_name;
    $_SESSION['amount'] = $amount;

}else{
    die("Database Error: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Booking Success</title>

<style>
body{
margin:0;
font-family:'Segoe UI', sans-serif;
background:linear-gradient(135deg,#11998e,#38ef7d);
}

/* Card */
.container{
max-width:520px;
margin:60px auto;
background:white;
border-radius:15px;
box-shadow:0 15px 30px rgba(0,0,0,0.2);
padding:30px;
text-align:center;
animation:fadeIn 1s ease;
}

/* Success Icon */
.checkmark{
font-size:70px;
color:#2ecc71;
animation:pop 0.5s ease;
}

/* Heading */
h2{
color:#2ecc71;
margin:10px 0;
}

/* Info */
.info{
text-align:left;
margin-top:20px;
line-height:1.8;
font-size:15px;
}

/* Button */
.btn{
display:inline-block;
margin-top:20px;
padding:12px 25px;
background:#3498db;
color:white;
text-decoration:none;
border-radius:6px;
transition:0.3s;
}
.btn:hover{
background:#2980b9;
}

/* Animation */
@keyframes fadeIn{
from{opacity:0; transform:translateY(20px);}
to{opacity:1; transform:translateY(0);}
}

@keyframes pop{
0%{transform:scale(0);}
100%{transform:scale(1);}
}

/* Confetti */
.confetti{
position:fixed;
width:10px;
height:10px;
top:0;
animation:fall 3s linear infinite;
}

@keyframes fall{
to{transform:translateY(100vh);}
}
</style>

</head>

<body>

<!-- 🎉 Confetti -->
<script>
for(let i=0;i<25;i++){
let conf=document.createElement("div");
conf.className="confetti";
conf.style.left=Math.random()*100+"%";
conf.style.backgroundColor=`hsl(${Math.random()*360},100%,50%)`;
conf.style.animationDuration=(Math.random()*3+2)+"s";
document.body.appendChild(conf);
}
</script>

<div class="container">

<div class="checkmark">✔</div>

<h2>Booking Confirmed!</h2>

<p>Your tour has been successfully booked 🎉</p>

<div class="info">
<p><strong>Name:</strong> <?php echo $name; ?></p>
<p><strong>Email:</strong> <?php echo $email; ?></p>
<p><strong>Package:</strong> <?php echo $package_name; ?></p>
<p><strong>Amount:</strong> ₹<?php echo $amount; ?></p>
<p><strong>Status:</strong> Cash on Arrival</p>
</div>

<a href="booking_confirmation.php" class="btn">View Booking Details</a>

</div>


</body>
</html>