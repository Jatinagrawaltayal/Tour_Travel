<?php
session_start(); // Start the session

// Check if the user is logged in
if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true) {
    // Unset all session variables
    $_SESSION = array();

    // If you want to destroy the session completely, also delete the session cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }

    // Finally, destroy the session
    session_destroy();
}

// Redirect to the home page or any other page
header("Location: home.php"); // Change to your desired page
exit();
?>