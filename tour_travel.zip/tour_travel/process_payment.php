<?php
include "includes/user_header.php"; // Include your database connection

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve booking details from the session
    if (!isset($_SESSION['booking_details'])) {
        // Redirect to booking page if session data is not set
        header("Location: book.php");
        exit();
    }

    $booking_details = $_SESSION['booking_details'];

    // Payment details
    $card_number = htmlspecialchars($_POST['card_number']);
    $expiry_date = htmlspecialchars($_POST['expiry_date']);
    $cvv = htmlspecialchars($_POST['cvv']);
    $cardholder_name = htmlspecialchars($_POST['cardholder_name']);

    // Here you would integrate your payment gateway (e.g., PayPal, Stripe, etc.)
    // For demonstration, let's assume the payment is successful.

    $payment_successful = true; // Simulate payment success

    if ($payment_successful) {
        // Insert booking details into the database
        $stmt = $conn->prepare("INSERT INTO bookings (user_id, name, email, phone, address, location, num_adults, num_children, booking_date, departure_date, total_amount, transport_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $user_id = $_SESSION['user_id']; // Assuming user_id is stored in session

        $stmt->bind_param("isssssiissds", 
            $user_id, 
            $booking_details['name'], 
            $booking_details['email'], 
            $booking_details['number'], 
            $booking_details['address'], 
            $booking_details['location'], 
            $booking_details['num_adults'], 
            $booking_details['num_children'], 
            $booking_details['booking_date'], 
            $booking_details['departure_date'], 
            $booking_details['total_amount'], 
            $booking_details['transport_name'] // Include transport name
        );

        if ($stmt->execute()) {
            // Get the last inserted booking ID
            $booking_id = $stmt->insert_id;

            // Now insert payment details into the payments table
            $payment_stmt = $conn->prepare("INSERT INTO payments (booking_id, cardholder_name, card_number, expiry_date, cvv, amount, payment_date) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $payment_date = date('Y-m-d H:i:s'); // Current date and time

            $payment_stmt->bind_param("issssds", 
                $booking_id, 
                $cardholder_name, 
                $card_number, 
                $expiry_date, 
                $cvv, 
                $booking_details['total_amount'], 
                $payment_date
            );

            if ($payment_stmt->execute()) {
                echo "<script>alert('Booking and payment successful!'); window.location.href='booking_confirmation.php';</script>";
            } else {
                echo "Error inserting payment details: " . $payment_stmt->error;
            }

            $payment_stmt->close();
        } else {
            echo "Error inserting booking details: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Payment failed. Please try again.";
    }
} else {
    // Redirect to booking page if accessed directly
    header("Location: book.php");
    exit();
}
?>