<?php
session_start();

// Redirect before any output
if (!isset($_SESSION['user_id'])) {
    header("Location: user_login_register.php");
    exit();
}

include "includes/user_header.php";

if(isset($_POST['submit']))
{
    $user_id = $_SESSION['user_id'];
    $message = $_POST['message'];

    $sql = "INSERT INTO feedbacks (user_id, message) VALUES (?, ?)";

    $stmt = $conn->prepare($sql);

    if($stmt)
    {
        $stmt->bind_param("is", $user_id, $message);
        $stmt->execute();

        echo "<script>alert('Feedback submitted successfully'); window.location.href='feedback.php';</script>";
    }
    else
    {
        echo "SQL Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Feedback</title>

<style>

.feedback-container{
max-width:600px;
margin:40px auto;
padding:20px;
background:white;
box-shadow:0 0 10px rgba(0,0,0,0.1);
border-radius:8px;
}

h2{
text-align:center;
color:#3498db;
}

textarea{
width:100%;
padding:10px;
margin-top:10px;
margin-bottom:20px;
border:1px solid #ccc;
border-radius:5px;
}

button{
background:#3498db;
color:white;
border:none;
padding:10px 20px;
border-radius:5px;
cursor:pointer;
}

button:hover{
background:#2980b9;
}

</style>

</head>

<body>

<div class="feedback-container">

<h2>Submit Your Feedback</h2>

<form method="POST">

<label>Your Message</label>

<textarea name="message" rows="5" required placeholder="Write your feedback here..."></textarea>

<button type="submit" name="submit">Submit Feedback</button>

</form>

</div>

<?php include "includes/user_footer.php"; ?>

</body>
</html>