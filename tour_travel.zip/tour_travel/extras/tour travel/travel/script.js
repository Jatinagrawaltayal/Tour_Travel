// Function to display the booking form based on selected transport
function showBookingForm(transportType) {
    // Hide all forms
    document.getElementById('train-form').style.display = 'none';
    document.getElementById('flight-form').style.display = 'none';
    document.getElementById('bus-form').style.display = 'none';

    // Show the selected transport form
    document.getElementById(transportType + '-form').style.display = 'block';

    // Reset the destination and time fields
    resetFields(transportType);
}

// Function to reset fields (destination and time) based on selected transport type
function resetFields(transportType) {
    // Get the relevant form's destination and time fields
    const destinationField = document.getElementById(transportType === 'train' ? 'destination' : transportType + '-destination');
    const timeField = document.getElementById(transportType === 'train' ? 'train-time' : transportType + '-time');

    // Reset the destination dropdown
    destinationField.selectedIndex = 0;

    // Clear the available time dropdown
    timeField.innerHTML = '';
}

// Function to populate available times based on selected destination
function updateAvailableTimes(transportType) {
    const destination = document.getElementById(transportType === 'train' ? 'destination' : transportType + '-destination').value;
    const timeField = document.getElementById(transportType === 'train' ? 'train-time' : transportType + '-time');

    // If no destination is selected, clear the available times
    if (!destination) {
        timeField.innerHTML = '';
        return;
    }

    // Define available times for each destination (dummy times here, can be extended)
    const availableTimes = {
        'train': {
            'Mumbai': ['10:00 AM', '02:00 PM', '06:00 PM'],
            'Delhi': ['08:00 AM', '01:00 PM', '05:00 PM'],
            'Bangalore': ['07:00 AM', '12:00 PM', '04:00 PM'],
            'Chennai': ['09:00 AM', '03:00 PM', '07:00 PM'],
            'Kolkata': ['10:30 AM', '02:30 PM', '06:30 PM'],
            'Hyderabad': ['08:30 AM', '01:30 PM', '05:30 PM'],
            'Jaipur': ['11:00 AM', '03:00 PM', '07:00 PM'],
            'Pune': ['09:30 AM', '01:30 PM', '05:30 PM'],
            'Lucknow': ['07:30 AM', '12:30 PM', '04:30 PM'],
            'Ahmedabad': ['08:00 AM', '02:00 PM', '06:00 PM']
        },
        'flight': {
            'Indira Gandhi International Airport': ['08:00 AM', '12:00 PM', '04:00 PM'],
            'Chhatrapati Shivaji Maharaj International Airport': ['09:00 AM', '01:00 PM', '05:00 PM'],
            'Kempegowda International Airport': ['07:30 AM', '11:30 AM', '03:30 PM'],
            'Netaji Subhas Chandra Bose International Airport': ['08:30 AM', '12:30 PM', '04:30 PM'],
            'Rajiv Gandhi International Airport': ['09:30 AM', '01:30 PM', '05:30 PM'],
            'Sardar Vallabhbhai Patel International Airport': ['10:00 AM', '02:00 PM', '06:00 PM'],
            'Chennai International Airport': ['09:00 AM', '01:00 PM', '05:00 PM'],
            'Jaipur International Airport': ['08:30 AM', '12:30 PM', '04:30 PM'],
            'Pune International Airport': ['07:30 AM', '11:30 AM', '03:30 PM']
        },
        'bus': {
            'Indira Gandhi International Airport': ['08:00 AM', '12:00 PM', '04:00 PM'],
            'Chhatrapati Shivaji Maharaj International Airport': ['09:00 AM', '01:00 PM', '05:00 PM'],
            'Kempegowda International Airport': ['07:30 AM', '11:30 AM', '03:30 PM'],
            'Netaji Subhas Chandra Bose International Airport': ['08:30 AM', '12:30 PM', '04:30 PM'],
            'Rajiv Gandhi International Airport': ['09:30 AM', '01:30 PM', '05:30 PM'],
            'Sardar Vallabhbhai Patel International Airport': ['10:00 AM', '02:00 PM', '06:00 PM'],
            'Chennai International Airport': ['09:00 AM', '01:00 PM', '05:00 PM'],
            'Jaipur International Airport': ['08:30 AM', '12:30 PM', '04:30 PM'],
            'Pune International Airport': ['07:30 AM', '11:30 AM', '03:30 PM']
        },

    };

    // Get the available times for the selected destination
    const times = availableTimes[transportType][destination];

    // Populate the time dropdown
    timeField.innerHTML = '';
    if (times) {
        times.forEach(time => {
            const option = document.createElement('option');
            option.value = time;
            option.textContent = time;
            timeField.appendChild(option);
        });
    }
}

// Add event listeners to the destination fields for each transport
document.getElementById('destination').addEventListener('change', function() {
    updateAvailableTimes('train');
});

document.getElementById('flight-destination').addEventListener('change', function() {
    updateAvailableTimes('flight');
});

document.getElementById('bus-destination').addEventListener('change', function() {
    updateAvailableTimes('bus');
});
function showBookingForm(mode) {
    // Hide all booking forms
    const forms = document.querySelectorAll('.book-container');
    forms.forEach(form => {
        form.style.display = 'none';
    });

    // Show the selected form (train)
    if (mode === 'train') {
        document.getElementById('train-form').style.display = 'block';
    }
}
function showBookingForm(mode) {
    // Hide all booking forms initially
    const forms = document.querySelectorAll('.book-container');
    forms.forEach(form => {
        form.style.display = 'none';
    });

    // Show the selected form (train only)
    if (mode === 'train') {
        document.getElementById('train-form').style.display = 'block';
    }
}

// Disable the "Flight" and "Bus" buttons by default
document.getElementById("flight-button").disabled = true;
document.getElementById("bus-button").disabled = true;
// Function to show the appropriate booking form based on the selected transport
function showBookingForm(type) {
    // Hide all forms
    document.getElementById('train-form').style.display = 'none';
    document.getElementById('flight-form').style.display = 'none';
    document.getElementById('bus-form').style.display = 'none';

    // Show the selected form
    if (type === 'train') {
        document.getElementById('train-form').style.display = 'block';
    } else if (type === 'flight') {
        document.getElementById('flight-form').style.display = 'block';
        loadFlightTimes(); // Assuming you want to load dynamic flight times
    } else if (type === 'bus') {
        document.getElementById('bus-form').style.display = 'block';
        loadBusTimes(); // Assuming you want to load dynamic bus times
    }
}

// Example function to dynamically load flight times (you can replace this with real data if needed)
function loadFlightTimes() {
    const flightTimeSelect = document.getElementById('flight-time');
    flightTimeSelect.innerHTML = ''; // Clear any existing options

    // Example flight times
    const times = ['10:00 AM', '02:00 PM', '06:00 PM', '08:00 PM'];
    times.forEach(time => {
        const option = document.createElement('option');
        option.value = time;
        option.textContent = time;
        flightTimeSelect.appendChild(option);
    });
}

// Example function to dynamically load bus times (you can replace this with real data if needed)
function loadBusTimes() {
    const busTimeSelect = document.getElementById('bus-time');
    busTimeSelect.innerHTML = ''; // Clear any existing options

    // Example bus times
    const times = ['09:00 AM', '01:00 PM', '05:00 PM', '07:00 PM'];
    times.forEach(time => {
        const option = document.createElement('option');
        option.value = time;
        option.textContent = time;
        busTimeSelect.appendChild(option);
    });
}

