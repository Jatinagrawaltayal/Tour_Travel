document.getElementById('support-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting normally

    // Get form data
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    // Simple form validation
    if (!name || !email || !message) {
        alert('Please fill out all fields before submitting.');
        return;
    }

    // Simulate a form submission (you would send this data to your server here)
    setTimeout(function() {
        // Clear the form
        document.getElementById('support-form').reset();

        // Display success message
        const responseMessage = document.getElementById('response-message');
        responseMessage.textContent = 'Thank you for reaching out! Your message has been sent successfully.';
        responseMessage.style.color = 'green';
    }, 1000); // Simulate network delay for demonstration purposes
});
