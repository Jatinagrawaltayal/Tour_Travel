// Array of packages
const packages = [
    { name: "Honeymoon Package", price: 2000, city: "New York", state: "NY" },
    { name: "Temple Package", price: 1500, city: "Los Angeles", state: "CA" },
    { name: "Desert Package", price: 2500, city: "Las Vegas", state: "NV" },
    { name: "Kashmir Package", price: 3000, city: "Srinagar", state: "JK" },
    { name: "Chardham Yatra Package", price: 5000, city: "Dehradun", state: "UK" },
    { name: "Himachal Package", price: 3500, city: "Shimla", state: "HP" },
    { name: "Kerala Backwaters Package", price: 4000, city: "Kochi", state: "KL" },
    { name: "Andaman Beach Package", price: 4500, city: "Port Blair", state: "AN" },
    { name: "Sri Lanka Tour Package", price: 6000, city: "Colombo", state: "SL" },
    { name: "Rajasthan Cultural Package", price: 5500, city: "Jaipur", state: "RJ" },
    { name: "Mussoorie Hill Station Package", price: 2500, city: "Mussoorie", state: "UK" },
    { name: "All India Tour Package", price: 10000, city: "Multiple Cities", state: "All" },
    // Add more packages here as needed
];

// Function to dynamically add package names to the header
function addPackagesToHeader() {
    const packageList = document.getElementById('packageList');

    // Clear existing list items (if any)
    packageList.innerHTML = '';

    // Add each package name to the header
    packages.forEach(pkg => {
        const listItem = document.createElement('li');
        listItem.textContent = pkg.name;
        packageList.appendChild(listItem);
    });
}

// Function to dynamically add packages to the booking form dropdown
function addPackagesToDropdown() {
    const packageSelect = document.getElementById('packageSelect');

    // Clear existing options (if any)
    packageSelect.innerHTML = '<option value="">--Select a Package--</option>';

    // Add each package to the dropdown
    packages.forEach(pkg => {
        const option = document.createElement('option');
        option.value = pkg.price;
        option.textContent = pkg.name;
        packageSelect.appendChild(option);
    });
}

// Call the functions to add packages
addPackagesToHeader();
addPackagesToDropdown();

// Search functionality
document.getElementById('searchForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const city = document.getElementById('city').value.toLowerCase();
    const state = document.getElementById('state').value.toLowerCase();

    const packageElements = document.querySelectorAll('.package');
    packageElements.forEach(pkg => {
        const pkgCity = pkg.getAttribute('data-city').toLowerCase();
        const pkgState = pkg.getAttribute('data-state').toLowerCase();

        if (pkgCity === city && pkgState === state) {
            pkg.style.display = 'block';
        } else {
            pkg.style.display = 'none';
        }
    });
});

// Booking functionality
document.getElementById('bookingForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const packagePrice = parseInt(document.getElementById('packageSelect').value);
    const adults = parseInt(document.getElementById('adults').value);
    const children = parseInt(document.getElementById('children').value);

    const adultPrice = packagePrice * adults;
    const childPrice = (packagePrice / 2) * children;
    const totalAmount = adultPrice + childPrice;

    document.getElementById('totalAmount').textContent = totalAmount;
});
document.addEventListener('DOMContentLoaded', function() {
    const packages = [
        {
            name: 'Honeymoon Package',
            city: 'New York',
            state: 'NY',
            image: 'honeymoon_package.jpg',
            description: 'Enjoy a romantic getaway in New York with a luxurious stay and special experiences tailored for couples.',
            priceAdult: 2000,
            priceChild: 1000
        },
        {
            name: 'Temple Package',
            city: 'Los Angeles',
            state: 'CA',
            image: 'temple_package.jpg',
            description: 'Explore the rich spiritual heritage of Los Angeles through temple visits and serene experiences.',
            priceAdult: 1500,
            priceChild: 750
        },
        {
            name: 'Desert Package',
            city: 'Las Vegas',
            state: 'NV',
            image: 'desert_package.jpg',
            description: 'Discover the beauty of the desert landscapes with exciting activities and luxurious accommodations.',
            priceAdult: 2500,
            priceChild: 1250
        },
         {
            name: 'Kashmir Package',
            city: 'Kashmir',
            state: 'Jmmbu',
            image: '',
            description: 'Kashmir is a mountainous region in India known for its natural beauty, which includes lakes, rivers, and valleys. It's often called "Paradise on Earth.',
            priceAdult: 6500,
            priceChild: 1250
        },

        // Add more packages here as needed
    ];

    // Dynamically create the packages in the HTML
    const packagesSection = document.getElementById('packages');
    packages.forEach(pkg => {
        const packageDiv = document.createElement('div');
        packageDiv.classList.add('package');
        packageDiv.setAttribute('data-city', pkg.city);
        packageDiv.setAttribute('data-state', pkg.state);

        packageDiv.innerHTML = `
            <img src="${pkg.image}" alt="${pkg.name}" class="package-image">
            <h3>${pkg.name}</h3>
            <p class="description">${pkg.description}</p>
            <p>Price: $${pkg.priceAdult} per adult, $${pkg.priceChild} per child</p>
        `;

        packagesSection.appendChild(packageDiv);
    });

    // Populate the package selection dropdown for booking
    const packageSelect = document.getElementById('packageSelect');
    packages.forEach(pkg => {
        const option = document.createElement('option');
        option.value = pkg.name;
        option.textContent = pkg.name;
        packageSelect.appendChild(option);
    });
});
