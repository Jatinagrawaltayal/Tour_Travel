document.getElementById('payment-form').addEventListener('submit', function(event) {
    event.preventDefault();

    // Show loading spinner
    const loadingSpinner = document.getElementById('loading-spinner');
    const payButton = document.querySelector('.pay-button');
    const qrCodeElement = document.getElementById('qr-code');
    
    // Disable the pay button to prevent multiple clicks
    payButton.classList.add('loading');
    loadingSpinner.style.display = 'inline-block'; // Show the spinner
    qrCodeElement.style.display = 'none'; // Hide QR code section during the loading

    // Simulate a delay for payment processing (e.g., API call to process payment)
    setTimeout(() => {
        // Get input values
        const phone = document.getElementById('phone').value;
        const amount = document.getElementById('amount').value;
        const upi = document.getElementById('upi').value;
        const paymentMethod = document.getElementById('payment-method').value;

        // Generate a QR code (for UPI)
        qrCodeElement.innerHTML = ''; // Clear previous QR code
        const qrData = `upi://pay?pa=${upi}&pn=YourName&mc=YourMerchantCode&tid=YourTransactionId&tr=12345&tn=Payment+for+${amount}&am=${amount}&cu=INR`;
        new QRCode(qrCodeElement, qrData);

        // Show QR code after processing
        qrCodeElement.style.display = 'block';
        
        // Create a success message and add transaction to the history
        const successMessage = `Payment of ₹${amount} via ${paymentMethod} is successful!`;

        // Create a transaction record
        const transactionDate = new Date().toLocaleString();
        const transactionStatus = 'Successful';

        // Add the transaction to the table
        const tableBody = document.querySelector('#transaction-table tbody');
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${transactionDate}</td>
            <td>${phone}</td>
            <td>₹${amount}</td>
            <td>${upi}</td>
            <td>${paymentMethod}</td>
            <td>${transactionStatus}</td>
        `;
        tableBody.appendChild(row);

        // Hide the loading spinner and re-enable the button
        loadingSpinner.style.display = 'none';
        payButton.classList.remove('loading');
        
        // Show success message (could also show a popup or notification)
        alert(successMessage);
    }, 2000); // Simulate 2-second processing delay
});
