// Example Hotel Data
const hotels = [
    { name: "Hotel NYC", city: "new-york", price: 200, rating: 4, amenities: ["wifi", "parking"], latitude: 40.7128, longitude: -74.006 },
    { name: "Eiffel Hotel", city: "paris", price: 300, rating: 5, amenities: ["wifi", "pool"], latitude: 48.8566, longitude: 2.3522 },
    { name: "Tokyo Stay", city: "tokyo", price: 150, rating: 3, amenities: ["wifi", "parking"], latitude: 35.6895, longitude: 139.6917 },
];

// Selected Filters
let selectedCity = "all";
let selectedPrice = 500;
let selectedRating = "all";
let selectedAmenities = [];

// Elements
const cityDropdown = document.getElementById("city-dropdown");
const priceRangeInput = document.getElementById("price-range");
const starRatingSelect = document.getElementById("star-rating");
const hotelsContainer = document.getElementById("hotels-container");
const reviewsList = document.getElementById("reviews-list");

// Update Filters
cityDropdown.addEventListener("change", (e) => {
    selectedCity = e.target.value;
    renderHotels();
});

priceRangeInput.addEventListener("input", (e) => {
    selectedPrice = e.target.value;
    document.getElementById("price-display").textContent = `$${selectedPrice}`;
    renderHotels();
});

starRatingSelect.addEventListener("change", (e) => {
    selectedRating = e.target.value;
    renderHotels();
});

document.querySelectorAll(".amenity").forEach((checkbox) => {
    checkbox.addEventListener("change", () => {
        selectedAmenities = Array.from(document.querySelectorAll(".amenity:checked")).map(cb => cb.value);
        renderHotels();
    });
});

// Render Hotels
function renderHotels() {
    hotelsContainer.innerHTML = "";
    const filteredHotels = hotels.filter(hotel =>
        (selectedCity === "all" || hotel.city === selectedCity) &&
        hotel.price <= selectedPrice &&
        (selectedRating === "all" || hotel.rating == selectedRating) &&
        selectedAmenities.every(amenity => hotel.amenities.includes(amenity))
    );
    filteredHotels.forEach(hotel => {
        const hotelBox = document.createElement("div");
        hotelBox.classList.add("box");
        hotelBox.innerHTML = `
            <img src="https://via.placeholder.com/300x200" alt="${hotel.name}" />
            <h3>${hotel.name}</h3>
            <p>Price: $${hotel.price}</p>
            <p>Rating: ${hotel.rating} Stars</p>
        `;
        hotelsContainer.appendChild(hotelBox);
    });
}

// Initialize Map
function initMap() {
    const map = L.map("map").setView([37.7749, -122.4194], 3);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png").addTo(map);

    hotels.forEach(hotel => {
        L.marker([hotel.latitude, hotel.longitude]).addTo(map)
            .bindPopup(`<b>${hotel.name}</b><br>Price: $${hotel.price}`);
    });
}

// Handle Reviews
document.getElementById("submit-review").addEventListener("click", () => {
    const reviewInput = document.getElementById("review-input");
    if (reviewInput.value.trim()) {
        const li = document.createElement("li");
        li.textContent = reviewInput.value;
        reviewsList.appendChild(li);
        reviewInput.value = "";
    }
});

// Initialize
renderHotels();
initMap();
