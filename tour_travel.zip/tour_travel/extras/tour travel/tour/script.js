// Sample hotel data
const hotels = [
    {
        name: "Hotel Mumbai Luxury",
        city: "Mumbai",
        price: 250,
        rating: 5,
        amenities: ["wifi", "pool", "parking"],
        image: "https://skift.com/wp-content/uploads/2024/04/Uday-Palace-Navsari-Radisson-Individuals.jpeg",
    },
    {
        name: "Beachfront Goa Resort",
        city: "Goa",
        price: 100,
        rating: 4,
        amenities: ["wifi", "pool"],
        image: "https://www.bagpack2go.com/admin/webroot/img/uploads/holiday-package-gallery/1607410889_345172-baga-marina-resort24.jpg",
    },
    {
        name: "Heritage Chennai",
        city: "Chennai",
        price: 200,
        rating: 3,
        amenities: ["wifi", "parking"],
        image: "https://www.gingerhotels.com/resourcefiles/hotelprofile/new-fff.jpg?version=1152025053419",
    },
    {
        name: "Delhi Downtown Stay",
        city: "Delhi",
        price: 150,
        rating: 4,
        amenities: ["wifi", "parking"],
        image: "https://cf.bstatic.com/xdata/images/hotel/max1024x768/518332246.jpg?k=852d9e83009ac082a7bb8366d5e27fb1f21801ea9cb6dde9c14e1aa99c49ea63&o=&hp=1",
    },
    {
        name: "Jaipur Royal Palace",
        city: "Jaipur",
        price: 350,
        rating: 5,
        amenities: ["wifi", "pool", "parking"],
        image: "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/2c/20/5a/17/rambagh-palace-exterior.jpg?w=1200&h=-1&s=1",
    },
    {
        name: "Taj Hotal",
        city: "Delhi",
        price: 500,
        rating: 5,
        amenities: ["wifi"],
        image: "https://cdn.sanity.io/images/ocl5w36p/prod2/d82b5f532cf2b62e7dc32ee6ddccd6d8af074cba-3840x1860.jpg",
    },
  {
        name: "Ahmedabad INN",
        city: "Ahmedabad",
        price: 100,
        rating: 4,
        amenities: ["wifi"],
        image: "https://r2imghtlak.mmtcdn.com/r2-mmt-htl-image/htl-imgs/202011191500502487-5cba545865fd11eb8aae0242ac110003.jpg?&output-quality=75&downsize=328:180&crop=328:180;0,74&output-format=jpg",
    },
    {
        name: "Taj Hotal",
        city: "Mumbai",
        price: 450,
        rating: 5,
        amenities: ["wifi", "pool", "parking"],
        image: "https://media.gettyimages.com/id/520443060/photo/the-taj-mahal-palace-hotel-at-dusk.jpg?s=170667a&w=gi&k=20&c=AocGtfg598aggwYDImIOoG4ihNME4kds2iCUn7MwD1g="
    },
    {
        name: "SunSpary Resort",
        city: "Jaipur",
        price: 450,
        rating: 3,
        amenities: ["wifi"],
        image: "https://media.istockphoto.com/id/907614450/photo/luxury-resort-hotel-with-swimming-pool-at-sunset.jpg?s=612x612&w=0&k=20&c=eUijzw-MkPw00HAw464I3mwa4b17yhrfvh5HiGZiEqo=",
    },
    {
        name: "Happy Stay",
        city: "Ahmedabad",
        price: 500,
        rating: 3,
        amenities: ["wifi"],
        image: "https://www.specialholidays.com/blog/wp-content/uploads/2021/05/itc-grand-chola-chennai-tamil-nadu.jpg",
    },


];

// Function to display hotels
function displayHotels(filteredHotels) {
    const container = document.getElementById("hotels-container");
    container.innerHTML = ""; // Clear any existing hotels

    if (filteredHotels.length === 0) {
        container.innerHTML = "<p>No hotels found matching your criteria.</p>";
        return;
    }

    filteredHotels.forEach(hotel => {
        const hotelBox = document.createElement("div");
        hotelBox.classList.add("hotel-box");

        hotelBox.innerHTML = `
            <img src="${hotel.image}" alt="${hotel.name}" />
            <div class="hotel-details">
                <h3>${hotel.name}</h3>
                <p>City: ${hotel.city}</p>
                <p>Price: $${hotel.price}</p>
                <p>Rating: ${hotel.rating} Stars</p>
                <p>Amenities: ${hotel.amenities.join(", ")}</p>
            </div>
        `;

        container.appendChild(hotelBox);
    });
}

// Filter hotels based on selected criteria
function filterHotels() {
    const city = document.getElementById("city-dropdown").value;
    const maxPrice = parseInt(document.getElementById("price-range").value);
    const rating = document.getElementById("star-rating").value;
    const selectedAmenities = Array.from(document.querySelectorAll(".amenity:checked")).map(el => el.value);

    let filteredHotels = hotels;

    // Filter by city
    if (city !== "all") {
        filteredHotels = filteredHotels.filter(hotel => hotel.city === city);
    }

    // Filter by price
    filteredHotels = filteredHotels.filter(hotel => hotel.price <= maxPrice);

    // Filter by rating
    if (rating !== "all") {
        filteredHotels = filteredHotels.filter(hotel => hotel.rating === parseInt(rating));
    }

    // Filter by amenities
    if (selectedAmenities.length > 0) {
        filteredHotels = filteredHotels.filter(hotel =>
            selectedAmenities.every(amenity => hotel.amenities.includes(amenity))
        );
    }

    displayHotels(filteredHotels);
}

// Adjust price range using + and - buttons
function adjustPriceRange(change) {
    const priceRange = document.getElementById("price-range");
    const currentPrice = parseInt(priceRange.value);
    const newPrice = Math.min(Math.max(currentPrice + change, parseInt(priceRange.min)), parseInt(priceRange.max));
    priceRange.value = newPrice;
    document.getElementById("price-display").textContent = `$${newPrice}`;
    filterHotels();
}

// Event listeners
document.getElementById("city-dropdown").addEventListener("change", filterHotels);
document.getElementById("price-range").addEventListener("input", () => {
    document.getElementById("price-display").textContent = `$${document.getElementById("price-range").value}`;
    filterHotels();
});
document.getElementById("star-rating").addEventListener("change", filterHotels);
document.querySelectorAll(".amenity").forEach(checkbox => checkbox.addEventListener("change", filterHotels));

// Add event listeners for price adjustment buttons
document.getElementById("price-decrease").addEventListener("click", () => adjustPriceRange(-50));
document.getElementById("price-increase").addEventListener("click", () => adjustPriceRange(50));

// Initial display of all hotels
displayHotels(hotels);
// Function to calculate and display discounted price
function applyDiscount(hotelPrice) {
    const discountRate = 20; // 20% discount
    const discountedPrice = hotelPrice - (hotelPrice * discountRate) / 100;
    return discountedPrice.toFixed(2);
}

// Update displayHotels to include discounted prices
function displayHotels(filteredHotels) {
    const container = document.getElementById("hotels-container");
    container.innerHTML = ""; // Clear any existing hotels

    if (filteredHotels.length === 0) {
        container.innerHTML = "<p>No hotels found matching your criteria.</p>";
        return;
    }

    filteredHotels.forEach(hotel => {
        const hotelBox = document.createElement("div");
        hotelBox.classList.add("hotel-box");

        const discountedPrice = applyDiscount(hotel.price);

        hotelBox.innerHTML = `
            <img src="${hotel.image}" alt="${hotel.name}" />
            <div class="hotel-details">
                <h3>${hotel.name}</h3>
                <p>City: ${hotel.city}</p>
                <p>Original Price: <s>$${hotel.price}</s></p>
                <p>Discounted Price: <strong>$${discountedPrice}</strong></p>
                <p>Rating: ${hotel.rating} Stars</p>
                <p>Amenities: ${hotel.amenities.join(", ")}</p>
            </div>
        `;

        container.appendChild(hotelBox);
    });
}

// Initial display of all hotels
displayHotels(hotels);

