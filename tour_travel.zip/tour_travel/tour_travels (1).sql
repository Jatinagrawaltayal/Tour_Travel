-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 31, 2026 at 01:50 PM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tour&travels`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `admin_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
CREATE TABLE IF NOT EXISTS `bookings` (
  `book_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `address` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `num_adults` int NOT NULL,
  `num_children` int DEFAULT NULL,
  `departure_date` date NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `booking_date` date NOT NULL,
  PRIMARY KEY (`book_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`book_id`, `user_id`, `name`, `email`, `phone`, `address`, `location`, `num_adults`, `num_children`, `departure_date`, `total_amount`, `booking_date`) VALUES
(22, 6, 'Jatin Agrawal', 'Jatinagrawal835@gmail.com', '07073935694', 'Ramdev Mandir ke pass mungthala', 'Jaisalmer Tour', 2, 2, '2026-02-23', '6000.00', '2026-02-08'),
(21, 6, 'Jatin Agrawal', 'Jatinagrawal835@gmail.com', '07073935694', 'Ramdev Mandir ke pass mungthala', 'Jaisalmer Tour', 2, 2, '2026-02-23', '6000.00', '2026-02-08');

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

DROP TABLE IF EXISTS `feedbacks`;
CREATE TABLE IF NOT EXISTS `feedbacks` (
  `feedback_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `message` text,
  PRIMARY KEY (`feedback_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `feedbacks`
--

INSERT INTO `feedbacks` (`feedback_id`, `user_id`, `message`) VALUES
(1, 7, 'nice'),
(2, 7, 'nice'),
(3, 7, 'best tour');

-- --------------------------------------------------------

--
-- Table structure for table `itineraries`
--

DROP TABLE IF EXISTS `itineraries`;
CREATE TABLE IF NOT EXISTS `itineraries` (
  `itinerary_id` int NOT NULL AUTO_INCREMENT,
  `package_id` int NOT NULL,
  `day_number` int NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`itinerary_id`),
  KEY `package_id` (`package_id`)
) ENGINE=MyISAM AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `itineraries`
--

INSERT INTO `itineraries` (`itinerary_id`, `package_id`, `day_number`, `description`) VALUES
(1, 1, 1, 'Arrive in Delhi; explore India Gate and Connaught Place'),
(2, 1, 2, 'Sightseeing in Delhi; visit Red Fort, Qutub Minar, and Lotus Temple.'),
(3, 1, 3, 'Drive to Agra; visit Agra Fort and Mehtab Bagh for sunset views of the Taj Mahal.'),
(4, 1, 4, 'Early morning visit to the Taj Mahal; explore Itimad-ud-Daulah and local markets.'),
(5, 1, 5, 'Visit Fatehpur Sikri; return to Agra for shopping and relaxation.'),
(6, 1, 6, 'Drive to Jaipur; visit Hawa Mahal and local markets.'),
(7, 1, 7, 'Explore Amber Fort, City Palace, and Jantar Mantar in Jaipur.'),
(8, 1, 8, 'Drive back to Delhi; visit Chandni Chowk and enjoy a rickshaw ride.'),
(9, 1, 9, 'Fly to Varanasi; attend the Ganga Aarti ceremony at Dashashwamedh Ghat.'),
(10, 1, 10, 'Sunrise boat ride on the Ganges; visit Sarnath; depart from Varanasi.'),
(11, 2, 1, 'Arrive in Jaisalmer; visit Jaisalmer Fort and local markets.'),
(12, 2, 2, 'Explore Patwon Ki Haveli and Nathmal Ki Haveli; enjoy Gadisar Lake.'),
(13, 2, 3, 'Visit Sam Sand Dunes; enjoy camel rides and desert sunset.'),
(14, 2, 4, 'Experience a cultural evening with Rajasthani music and dance at the dunes.'),
(15, 2, 5, 'Day trip to Kuldhara Village and Khuri Sand Dunes.'),
(16, 2, 6, 'Visit the Desert National Park; explore local wildlife and landscapes.'),
(17, 2, 7, 'Depart from Jaisalmer; optional visit to local handicraft shops before leaving.'),
(41, 3, 3, 'Explore the historic Île de la Cité; visit Notre-Dame Cathedral and Sainte-Chapelle.'),
(40, 3, 2, 'Visit the Louvre Museum; stroll through the Tuileries Garden.'),
(39, 3, 1, 'Arrive in Paris; explore Montmartre and visit the Sacré-Cœur Basilica.'),
(42, 3, 4, 'Discover the Latin Quarter; visit the Panthéon and Luxembourg Gardens.'),
(43, 3, 5, 'Tour the Musée d\'Orsay; enjoy a Seine River cruise in the evening.'),
(44, 3, 6, 'Visit the Eiffel Tower; explore the Champ de Mars and Trocadéro Gardens.'),
(45, 3, 7, 'Day trip to Versailles; tour the Palace and Gardens of Versailles.'),
(46, 3, 8, 'Explore the Marais district; visit the Picasso Museum and Place des Vosges.'),
(47, 3, 9, 'Visit the Pompidou Center; enjoy shopping in the Le Marais area.'),
(48, 3, 10, 'Discover the Catacombs of Paris; explore the Montparnasse area.'),
(49, 3, 11, 'Visit the Palais Garnier (Opera House); enjoy a show or ballet if available.'),
(50, 3, 12, 'Explore the Canal Saint-Martin; relax at a café and enjoy local cuisine.'),
(51, 3, 13, 'Visit the Musée de l\'Orangerie; stroll along the Seine and visit the Pont Alexandre III.'),
(52, 3, 14, 'Explore the Bois de Vincennes; visit the Château de Vincennes.'),
(53, 3, 15, 'Last-minute shopping in the Galeries Lafayette; depart from Paris.'),
(54, 6, 1, 'Arrive in Bhubaneswar; visit the Lingaraj Temple and explore the local markets.'),
(55, 6, 2, 'Travel to Konark (about 1 hour); visit the Konark Sun Temple and explore the nearby Archaeological Museum.'),
(56, 6, 3, 'Relax at Chandrabhaga Beach; enjoy water sports and local seafood.'),
(57, 6, 4, 'Visit the Ramachandi Temple; explore the scenic coastline and enjoy sunset views.'),
(58, 6, 5, 'Day trip to Puri; visit the Jagannath Temple and relax on Puri Beach.'),
(59, 6, 6, 'Explore the Chilika Lake; take a boat ride to see dolphins and visit the Kalijai Island.'),
(60, 6, 7, 'Visit the Udayagiri and Khandagiri Caves; explore the ancient rock-cut caves and enjoy panoramic views.'),
(61, 6, 8, 'Return to Bhubaneswar; visit the Mukteshwar Temple and depart.'),
(62, 5, 1, 'Arrive in Chandigarh; drive to Shimla and explore the Mall Road.'),
(63, 5, 2, 'Visit Jakhoo Temple and the Ridge; enjoy local cuisine.'),
(64, 5, 3, 'Drive to Kufri; enjoy horse riding and visit the Himalayan Nature Park.'),
(65, 5, 4, 'Travel to Manali; explore the Old Manali village and local cafes.'),
(66, 5, 5, 'Visit Solang Valley for adventure sports; enjoy the scenic views.'),
(67, 5, 6, 'Day trip to Rohtang Pass; enjoy snow activities and stunning landscapes.'),
(68, 5, 7, 'Explore Manali; visit Hadimba Temple and Vashisht Village hot springs.'),
(69, 5, 8, 'Drive to Dharamshala; visit the Dalai Lama Temple and explore McLeod Ganj.'),
(70, 5, 9, 'Trek to Triund; enjoy panoramic views of the Dhauladhar range.'),
(71, 5, 10, 'Travel to Palampur; visit tea gardens and the Palampur Tea Factory.'),
(72, 5, 11, 'Drive to Bir Billing; enjoy paragliding and explore Tibetan monasteries.'),
(73, 5, 12, 'Travel to Kullu; visit the Kullu Valley and enjoy river rafting.'),
(74, 5, 13, 'Drive to Manikaran; visit the hot springs and Gurudwara.'),
(75, 5, 14, 'Return to Shimla; visit the Viceregal Lodge and Jakhoo Hill.'),
(76, 5, 15, 'Depart from Shimla to Chandigarh; explore local markets before departure.'),
(77, 9, 1, 'Arrival at Mount Abu, visit Dilwara Jain Temples, Nakki Lake, Local Market and enjoy sunset at Sunset Point.'),
(78, 9, 2, 'Visit Guru Shikhar, Achalgarh Fort, Peace Park and depart after sightseeing.');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

DROP TABLE IF EXISTS `packages`;
CREATE TABLE IF NOT EXISTS `packages` (
  `package_id` int NOT NULL AUTO_INCREMENT,
  `package_name` varchar(70) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `price_adult` decimal(10,2) NOT NULL,
  `price_infant` decimal(10,2) NOT NULL,
  `duration` int NOT NULL,
  `image` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `added_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `inclusions` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `exclusions` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `age_restrictions` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `contact_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`package_id`),
  UNIQUE KEY `package_name` (`package_name`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`package_id`, `package_name`, `description`, `price_adult`, `price_infant`, `duration`, `image`, `added_on`, `inclusions`, `exclusions`, `age_restrictions`, `contact_info`) VALUES
(1, 'Taj Mahal Tour', 'Visit the magnificent Taj Mahal, a symbol of love and one of the Seven Wonders of the World. Experience the beauty and history of this iconic landmark on our exclusive tour packages!', '5000.00', '1000.00', 10, 'assets/images/package_images/uploads/taj_mahal.jpg', '2025-02-15 19:16:10', 'Meals, transportation, and accommodation are included in this package.', 'Personal expenses, travel insurance, and optional activities are not included in this package.', 'This package is suitable for ages 5 and above. Children under 12 must be accompanied by an adult.', 'For inquiries, please contact us at tour@travels.com or call us at (123) 456-7890.'),
(2, 'Jaisalmer Tour', 'Discover the beauty of the golden city with our exclusive Jaisalmer tour packages.', '2500.00', '500.00', 7, 'assets/images/package_images/uploads/Jaisalmer.jpg', '2025-02-15 19:18:38', 'Meals, transportation, and accommodation are included in this package.', 'Personal expenses, travel insurance, and optional activities are not included in this package.', 'This package is suitable for ages 5 and above. Children under 12 must be accompanied by an adult.', 'For inquiries, please contact us at tour@travels.com or call us at (123) 456-7890.'),
(3, 'Paris Tour', 'Experience the charm of Paris with our exclusive Eiffel Tower tour packages. Witness the breathtaking cityscape from the top of this iconic landmark, enjoy guided tours rich with history, and indulge in romantic dinners under its sparkling lights.', '40000.00', '5000.00', 15, 'assets/images/package_images/uploads/paris.jpg', '2025-02-15 19:19:48', 'Meals, transportation, and accommodation are included in this package.', 'Personal expenses, travel insurance, and optional activities are not included in this package.', 'This package is suitable for ages 5 and above. Children under 12 must be accompanied by an adult.', 'For inquiries, please contact us at tour@travels.com or call us at (123) 456-7890.'),
(4, 'Kashmir Tour', 'Discover the paradise on earth—Kashmir! Enjoy serene lakes, snow-capped mountains, and breathtaking landscapes that make it a dream destination for every traveler.', '3000.00', '200.00', 20, 'assets/images/package_images/uploads/kashmir.jpg', '2025-02-15 19:21:35', 'Meals, transportation, and accommodation are included in this package.', 'Personal expenses, travel insurance, and optional activities are not included in this package.', 'This package is suitable for ages 5 and above. Children under 12 must be accompanied by an adult.', 'For inquiries, please contact us at tour@travels.com or call us at (123) 456-7890.'),
(5, 'Himachal Tour', 'Explore the mesmerizing beauty of Himachal Pradesh! From lush green valleys to snow-capped mountains, Himachal is a haven for adventure seekers and nature lovers alike.', '6000.00', '250.00', 15, 'assets/images/package_images/uploads/himachal.webp', '2025-02-15 19:33:12', 'Meals, transportation, and accommodation are included in this package.', 'Personal expenses, travel insurance, and optional activities are not included in this package.', 'This package is suitable for ages 5 and above. Children under 12 must be accompanied by an adult.', 'For inquiries, please contact us at tour@travels.com or call us at (123) 456-7890.'),
(6, 'Konark Sun Temple', 'Explore the ancient beauty of the Konark Sun Temple, a UNESCO World Heritage site. Immerse yourself in its architectural marvel and rich history, along with nearby cultural experiences.', '12000.00', '2000.00', 8, 'assets/images/package_images/uploads/konark.jpg', '2025-02-15 19:34:14', 'Meals, transportation, and accommodation are included in this package.', 'Personal expenses, travel insurance, and optional activities are not included in this package.', 'This package is suitable for ages 5 and above. Children under 12 must be accompanied by an adult.', 'For inquiries, please contact us at tour@travels.com or call us at (123) 456-7890.'),
(7, 'Singapore Tour', 'Discover the vibrant city of Singapore! From iconic landmarks like Marina Bay Sands to thrilling activities and cultural experiences, Singapore offers a blend of adventure and luxury.', '75000.00', '15000.00', 31, 'assets/images/package_images/uploads/singapore.webp', '2025-02-15 19:36:26', 'Meals, transportation, and accommodation are included in this package.', 'Personal expenses, travel insurance, and optional activities are not included in this package.', 'This package is suitable for ages 5 and above. Children under 12 must be accompanied by an adult.', 'For inquiries, please contact us at tour@travels.com or call us at (123) 456-7890.'),
(9, 'Abu Tour', 'Mount Abu is the only hill station of Rajasthan, located in the Aravalli Range.\r\nIt is known for its cool climate, green hills, and peaceful environment.\r\nMajor attractions include Nakki Lake, Dilwara Temples, and Guru Shikhar.\r\nThe town offers beautiful sunset points and scenic viewpoints.\r\nMount Abu is an ideal destination for nature lovers, families, and couples.', '900.00', '500.00', 2, 'assets/images/package_images/uploads/mount.jpg', '2026-01-02 05:58:25', 'Hotel stay, breakfast, local sightseeing, pickup & drop, taxes.', 'Meals other than breakfast, entry fees, personal expenses.', 'No age limit; kids below 5 years free (no extra bed).', 'Phone: +91 XXXXXXXXXX | Email: info@yourtour.com');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
CREATE TABLE IF NOT EXISTS `payments` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `package_name` varchar(100) DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `payment_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`payment_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `name`, `email`, `package_name`, `amount`, `payment_date`) VALUES
(1, 'Jatin Agrawal', 'Jatinagrawal835@gmail.com', 'Paris Tour', 80000, '2026-03-17 03:37:31'),
(2, 'Ramesh', 'ramesh@gmail.com', 'Himachal Tour', 6250, '2026-03-17 03:46:18'),
(3, 'pooja', 'pooja@gmail.com', 'Abu Tour', 1400, '2026-03-17 03:48:30'),
(4, 'Jatin Agrawal', 'Jatinagrawal835@gmail.com', 'Kashmir Tour', 3400, '2026-03-17 03:50:54'),
(15, 'Jatin Agrawal', 'Jatinagrawal835@gmail.com', 'Abu Tour', 1400, '2026-03-25 15:07:47'),
(14, 'Jatin Agrawal', 'Jatinagrawal835@gmail.com', 'Jaisalmer Tour', 5500, '2026-03-25 13:12:58'),
(13, 'Jatin Agrawal', 'Jatinagrawal835@gmail.com', 'Jaisalmer Tour', 3000, '2026-03-20 04:29:25'),
(12, 'ramesh', 'Jatinagrawal835@gmail.com', 'Abu Tour', 900, '2026-03-18 06:59:27'),
(11, 'Jatin Agrawal', 'Jatinagrawal835@gmail.com', 'Paris Tour', 40000, '2026-03-18 06:49:26'),
(16, 'Jatin Agrawal', 'Jatinagrawal835@gmail.com', 'Jaisalmer Tour', 2500, '2026-03-28 04:02:06'),
(17, 'Jatin Agrawal', 'Jatinagrawal835@gmail.com', 'Jaisalmer Tour', 2500, '2026-03-28 04:04:45');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `phone` int NOT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `phone`, `address`, `created_at`) VALUES
(7, 'Ramesh', 'Ramesh@gmail.com', '$2y$10$4DuwqPoDcUXTERCBeO/xX.DXA6/OVxosUxs1BrbByFmBbFEkMKLeW', 0, '', '2026-03-16 10:26:26'),
(6, 'pooja', 'pooja@gmail.com', '$2y$10$NMNxlSZ29GDnkOHHjaxSp.KQPp0168.QnTwLMoX/Ijq65rDt4Hmi2', 0, '', '2026-02-08 03:57:39'),
(5, 'jatin', 'jatin@gmail.com', '$2y$10$OlK.V3HWr..uNNs32nwOu.XlXlDax6k6mwD06DiRZH6siOBwQwYP6', 0, '', '2026-01-02 05:24:19');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
